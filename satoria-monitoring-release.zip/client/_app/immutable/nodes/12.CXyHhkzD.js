import{_ as m}from"../chunks/CoPNo8Uw.js";export{m as component};
