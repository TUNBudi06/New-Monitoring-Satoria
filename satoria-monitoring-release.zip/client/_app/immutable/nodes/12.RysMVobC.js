import{_ as m}from"../chunks/BKArwvzm.js";export{m as component};
