import{s as t,p as r}from"./CEdTP3zb.js";const a={get data(){return r.data},get error(){return r.error},get status(){return r.status},get url(){return r.url}};t.updated.check;export{a as p};
