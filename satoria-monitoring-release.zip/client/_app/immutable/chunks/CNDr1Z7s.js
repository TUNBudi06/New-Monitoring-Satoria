import{b as W,d as A,a as w,c as T}from"./DwO4VYHj.js";import{F as o,P as y,V as g,w as z,a3 as F,y as P,ad as I,Y as R,Z as V,U as p,T as x,C as j,z as B,x as G,O as M,p as O,a as U,c as Y,f as Z,s as q,b as D,r as H,g as v,aa as J,ae as K}from"./D9-ZRGEK.js";import{a as N,s as L}from"./_e2Lk8Wl.js";import{e as Q,i as X}from"./BdMBCV5W.js";import{i as $,p as c,r as ee}from"./CvF72XlB.js";function te(u,t,m,n,h,b){let _=o;o&&y();var i,r,e=null;o&&g.nodeType===1&&(e=g,y());var f=o?g:u,s;z(()=>{const a=t()||null;var l=m||a==="svg"?I:null;a!==i&&(s&&(a===null?B(s,()=>{s=null,r=null}):a===r?G(s):M(s)),a&&a!==r&&(s=P(()=>{if(e=o?e:l?document.createElementNS(l,a):document.createElement(a),W(e,e),n){o&&$(a)&&e.append(document.createComment(""));var d=o?R(e):e.appendChild(V());o&&(d===null?p(!1):x(d)),n(e,d)}j.nodes_end=e,f.before(e)})),i=a,i&&(r=i))},F),_&&(p(!0),x(f))}/**
 * @license @lucide/svelte v0.511.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const ae={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var se=A("<svg><!><!></svg>");function ce(u,t){O(t,!0);const m=c(t,"color",3,"currentColor"),n=c(t,"size",3,24),h=c(t,"strokeWidth",3,2),b=c(t,"absoluteStrokeWidth",3,!1),_=c(t,"iconNode",19,()=>[]),i=ee(t,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var r=se();N(r,s=>({...ae,...i,width:n(),height:n(),stroke:m(),"stroke-width":s,class:["lucide-icon lucide",t.name&&`lucide-${t.name}`,t.class]}),[()=>b()?Number(h())*24/Number(n()):h()]);var e=Y(r);Q(e,17,_,X,(s,a)=>{var l=J(()=>K(v(a),2));let d=()=>v(l)[0],C=()=>v(l)[1];var k=T(),E=Z(k);te(E,d,!0,(S,re)=>{N(S,()=>({...C()}))}),w(s,k)});var f=q(e);L(f,()=>t.children??D),H(r),w(u,r),U()}export{ce as I,te as e};
