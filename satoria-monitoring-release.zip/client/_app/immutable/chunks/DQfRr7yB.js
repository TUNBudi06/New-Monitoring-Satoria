new TextEncoder;
