import{Q as o,R as f,y as i,b as p,a0 as c,A as d,l as h}from"./CaKK9ONF.js";function y(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{y as s};
