import{N as o,O as f,o as i,x as p,Z as c,r as d,d as h}from"./N2H0PzE0.js";function l(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{l as s};
