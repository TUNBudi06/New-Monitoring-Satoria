import{b as T,d as z,a as p,c as R}from"./BFOTuOyR.js";import{A as o,k as w,l as _,O as j,a9 as B,y as F,ag as I,g as P,x as G,h as y,j as x,B as J,R as M,Q as O,a0 as Q,p as V,t as N,a as q,c as D,f as H,s as K,b as L,r as U,J as S}from"./CBtRJagN.js";import{s as X,a as A}from"./BZDqfNkc.js";import{e as Y,i as Z}from"./iv8aCNae.js";import{c as $,p as d,r as ee}from"./o7DcF9Ny.js";function te(u,t,g,i,m,v){let h=o;o&&w();var n,s,e=null;o&&_.nodeType===1&&(e=_,w());var l=o?_:u,r;j(()=>{const a=t()||null;var f=I;a!==n&&(r&&(a===null?M(r,()=>{r=null,s=null}):a===s?O(r):Q(r)),a&&a!==s&&(r=F(()=>{if(e=o?e:document.createElementNS(f,a),T(e,e),i){o&&$(a)&&e.append(document.createComment(""));var c=o?P(e):e.appendChild(G());o&&(c===null?y(!1):x(c)),i(e,c)}J.nodes_end=e,l.before(e)})),n=a,n&&(s=n))},B),h&&(y(!0),x(l))}/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const ae={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var se=z("<svg><!><!></svg>");function de(u,t){V(t,!0);const g=d(t,"color",3,"currentColor"),i=d(t,"size",3,24),m=d(t,"strokeWidth",3,2),v=d(t,"absoluteStrokeWidth",3,!1),h=d(t,"iconNode",19,()=>[]),n=ee(t,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var s=se();let e;var l=D(s);Y(l,17,h,Z,(a,f)=>{let c=()=>S(f)[0],C=()=>S(f)[1];var b=R(),E=H(b);te(E,c,!0,(W,re)=>{let k;N(()=>k=A(W,k,{...C()}))}),p(a,b)});var r=K(l);X(r,()=>t.children??L),U(s),N(a=>e=A(s,e,{...ae,...n,width:i(),height:i(),stroke:g(),"stroke-width":a,class:["lucide-icon lucide",t.name&&`lucide-${t.name}`,t.class]}),[()=>v()?Number(m())*24/Number(i()):m()]),p(u,s),q()}export{de as I};
