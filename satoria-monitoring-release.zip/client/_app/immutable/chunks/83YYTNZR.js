import{an as a}from"./GEnObDzR.js";a();
