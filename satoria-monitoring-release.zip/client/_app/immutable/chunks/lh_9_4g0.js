import{p}from"./DKdIxulT.js";const o=p;export{o as p};
