import"./CWj6FrbW.js";import{F as o,P as p,V as g,w as W,a2 as A,y as T,ae as z,Y as F,Z as P,U as w,T as y,C as I,z as R,x as V,O as j,p as B,a as G,c as M,f as O,s as U,b as Y,r as Z,g as v,a8 as q,af as D}from"./DXPuW9MO.js";import{b as H,d as J,a as x,c as K}from"./Bup8ca7u.js";import{a as N,s as L}from"./Y9se7Tnw.js";import{e as Q,i as X}from"./BgmoFf8y.js";import{i as $,p as d,r as ee}from"./BkC8TGyw.js";function te(u,t,m,n,h,b){let _=o;o&&p();var i,r,e=null;o&&g.nodeType===1&&(e=g,p());var f=o?g:u,s;W(()=>{const a=t()||null;var l=m||a==="svg"?z:null;a!==i&&(s&&(a===null?R(s,()=>{s=null,r=null}):a===r?V(s):j(s)),a&&a!==r&&(s=T(()=>{if(e=o?e:l?document.createElementNS(l,a):document.createElement(a),H(e,e),n){o&&$(a)&&e.append(document.createComment(""));var c=o?F(e):e.appendChild(P());o&&(c===null?w(!1):y(c)),n(e,c)}I.nodes_end=e,f.before(e)})),i=a,i&&(r=i))},A),_&&(w(!0),y(f))}/**
 * @license @lucide/svelte v0.511.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const ae={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var se=J("<svg><!><!></svg>");function fe(u,t){B(t,!0);const m=d(t,"color",3,"currentColor"),n=d(t,"size",3,24),h=d(t,"strokeWidth",3,2),b=d(t,"absoluteStrokeWidth",3,!1),_=d(t,"iconNode",19,()=>[]),i=ee(t,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var r=se();N(r,s=>({...ae,...i,width:n(),height:n(),stroke:m(),"stroke-width":s,class:["lucide-icon lucide",t.name&&`lucide-${t.name}`,t.class]}),[()=>b()?Number(h())*24/Number(n()):h()]);var e=M(r);Q(e,17,_,X,(s,a)=>{var l=q(()=>D(v(a),2));let c=()=>v(l)[0],C=()=>v(l)[1];var k=K(),E=O(k);te(E,c,!0,(S,re)=>{N(S,()=>({...C()}))}),x(s,k)});var f=U(e);L(f,()=>t.children??Y),Z(r),x(u,r),G()}export{fe as I,te as e};
