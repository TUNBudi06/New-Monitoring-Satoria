import{b as W,d as A,a as p,c as z}from"./SoUoNBie.js";import{i as o,j as w,z as g,l as T,aj as j,F,aq as q,O as G,Z as I,u as y,q as N,_ as P,G as R,E as B,ad as J,p as M,a as O,c as V,f as Z,s as D,b as H,r as K,g as v,J as L,ar as Q}from"./GEnObDzR.js";import{a as x,s as U}from"./Dur87Fff.js";import{e as X,i as Y}from"./DUTBo3uO.js";import{f as $,p as c,r as ee}from"./BIeUyJGK.js";function te(u,t,m,n,_,b){let h=o;o&&w();var i,r,e=null;o&&g.nodeType===1&&(e=g,w());var f=o?g:u,s;T(()=>{const a=t()||null;var l=m||a==="svg"?q:null;a!==i&&(s&&(a===null?R(s,()=>{s=null,r=null}):a===r?B(s):J(s)),a&&a!==r&&(s=F(()=>{if(e=o?e:l?document.createElementNS(l,a):document.createElement(a),W(e,e),n){o&&$(a)&&e.append(document.createComment(""));var d=o?G(e):e.appendChild(I());o&&(d===null?y(!1):N(d)),n(e,d)}P.nodes_end=e,f.before(e)})),i=a,i&&(r=i))},j),h&&(y(!0),N(f))}/**
 * @license @lucide/svelte v0.514.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 */const ae={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var se=A("<svg><!><!></svg>");function ce(u,t){M(t,!0);const m=c(t,"color",3,"currentColor"),n=c(t,"size",3,24),_=c(t,"strokeWidth",3,2),b=c(t,"absoluteStrokeWidth",3,!1),h=c(t,"iconNode",19,()=>[]),i=ee(t,["$$slots","$$events","$$legacy","name","color","size","strokeWidth","absoluteStrokeWidth","iconNode","children"]);var r=se();x(r,s=>({...ae,...i,width:n(),height:n(),stroke:m(),"stroke-width":s,class:["lucide-icon lucide",t.name&&`lucide-${t.name}`,t.class]}),[()=>b()?Number(_())*24/Number(n()):_()]);var e=V(r);X(e,17,h,Y,(s,a)=>{var l=L(()=>Q(v(a),2));let d=()=>v(l)[0],E=()=>v(l)[1];var k=z(),S=Z(k);te(S,d,!0,(C,re)=>{x(C,()=>({...E()}))}),p(s,k)});var f=D(e);U(f,()=>t.children??H),K(r),p(u,r),O()}export{ce as I,te as e};
