import{p}from"./jOYcctrt.js";const o=p;export{o as p};
