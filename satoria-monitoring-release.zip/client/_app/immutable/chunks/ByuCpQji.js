import{O as o,a9 as f,y as i,b as p,$ as c,A as d,l as h}from"./CLxiUi4l.js";function y(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{y as s};
