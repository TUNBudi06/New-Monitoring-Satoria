import{I as o,J as p,o as f,K as i,L as c,p as d,d as h}from"./D3ZwLoxx.js";function l(e,n,...t){var s=e,r=i,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=f(()=>r(s,...t)))},p),d&&(s=h)}export{l as s};
