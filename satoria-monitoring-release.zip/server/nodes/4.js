

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.Bk-yu6A3.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/Cv85WRB7.js"];
export const stylesheets = [];
export const fonts = [];
