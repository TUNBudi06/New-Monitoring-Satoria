import * as universal from '../entries/pages/(app)/configuration/_page.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/configuration/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/(app)/configuration/+page.ts";
export const imports = ["_app/immutable/nodes/5.CEJlFZqO.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/Cv85WRB7.js"];
export const stylesheets = [];
export const fonts = [];
