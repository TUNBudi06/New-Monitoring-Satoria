const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.4b2vVI5P.js",app:"_app/immutable/entry/app.D1pPN5B3.js",imports:["_app/immutable/entry/start.4b2vVI5P.js","_app/immutable/chunks/DteIz13L.js","_app/immutable/chunks/pyrCOowR.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/apuB4Uj0.js","_app/immutable/entry/app.D1pPN5B3.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/D5R5meCU.js","_app/immutable/chunks/Bl_P7zlk.js","_app/immutable/chunks/apuB4Uj0.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/pyrCOowR.js","_app/immutable/chunks/BDXrhozL.js","_app/immutable/chunks/0s6GNCna.js","_app/immutable/chunks/BTliYN56.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-B9NdCsRN.js')),
			__memo(() => import('./chunks/1-BIA2nMCc.js')),
			__memo(() => import('./chunks/2-CjfD_U1c.js')),
			__memo(() => import('./chunks/3-8B_UigPC.js')),
			__memo(() => import('./chunks/7-DTgHPoPK.js')),
			__memo(() => import('./chunks/8-DaILURhW.js')),
			__memo(() => import('./chunks/11-DyYHSIRJ.js')),
			__memo(() => import('./chunks/12-clXu-P-Y.js')),
			__memo(() => import('./chunks/13-CtOS6bi4.js')),
			__memo(() => import('./chunks/14-BDGUb3Jx.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-Bpl9ZWkC.js'))
		],
		routes: [
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 10 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
