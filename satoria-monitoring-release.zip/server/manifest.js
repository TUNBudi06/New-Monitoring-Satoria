const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.DRAMVVIt.js",app:"_app/immutable/entry/app.C4dlcyrb.js",imports:["_app/immutable/entry/start.DRAMVVIt.js","_app/immutable/chunks/Dnf__lyf.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/entry/app.C4dlcyrb.js","_app/immutable/chunks/D2gFui-Z.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/C7rFBrh4.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-BRH6G7JL.js')),
			__memo(() => import('./chunks/1-DEBHHZ8D.js')),
			__memo(() => import('./chunks/2-BGQzqZ1L.js')),
			__memo(() => import('./chunks/3-BWNoNtGb.js')),
			__memo(() => import('./chunks/4-BkZGIfSU.js')),
			__memo(() => import('./chunks/5-Ci8RPvS2.js')),
			__memo(() => import('./chunks/6-pprAqYAx.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-JvPq7b5o.js')),
			__memo(() => import('./chunks/8-DMNIAbyG.js')),
			__memo(() => import('./chunks/9-Dk7z6oys.js')),
			__memo(() => import('./chunks/10-L-SwHLtY.js')),
			__memo(() => import('./chunks/11-BNU6yoyT.js')),
			__memo(() => import('./chunks/12-n0kuoGeE.js')),
			__memo(() => import('./chunks/13-txXEg6yU.js')),
			__memo(() => import('./chunks/14-BalZYgtY.js')),
			__memo(() => import('./chunks/15-COXAibG2.js')),
			__memo(() => import('./chunks/16-BOmsfnEQ.js')),
			__memo(() => import('./chunks/17-DOHyWHhw.js')),
			__memo(() => import('./chunks/18-jV9C0pAh.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/19-CW9z3arg.js')),
			__memo(() => import('./chunks/20-Br4JyjPn.js'))
		],
		routes: [
			{
				id: "/(app)",
				pattern: /^\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/account",
				pattern: /^\/account\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(app)/account/admin",
				pattern: /^\/account\/admin\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/account/devices",
				pattern: /^\/account\/devices\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(app)/configuration",
				pattern: /^\/configuration\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2",
				pattern: /^\/configuration\/line2\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/atva",
				pattern: /^\/configuration\/line2\/atva\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 18 },
				endpoint: null
			},
			{
				id: "/logout",
				pattern: /^\/logout\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 20 },
				endpoint: null
			},
			{
				id: "/(app)/monitor",
				pattern: /^\/monitor\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2",
				pattern: /^\/monitor\/line2\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 19 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
