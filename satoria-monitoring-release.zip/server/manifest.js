const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.Cm9fSOuN.js",app:"_app/immutable/entry/app.BXJ4N0US.js",imports:["_app/immutable/entry/start.Cm9fSOuN.js","_app/immutable/chunks/DDygTKsk.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/DSQ_1cCE.js","_app/immutable/entry/app.BXJ4N0US.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/CNPJXPZ7.js","_app/immutable/chunks/CvhWP5Ll.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D-A_H2yJ.js","_app/immutable/chunks/BQFXtdII.js","_app/immutable/chunks/je7EIwxK.js","_app/immutable/chunks/DSQ_1cCE.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-CAcTfhnb.js')),
			__memo(() => import('./chunks/1-DBbHZJ_w.js')),
			__memo(() => import('./chunks/2-7Ux10our.js')),
			__memo(() => import('./chunks/3-C8t8Vq9u.js')),
			__memo(() => import('./chunks/4-CA4wk_Tv.js')),
			__memo(() => import('./chunks/6-DGu7za6m.js')),
			__memo(() => import('./chunks/7-BycUfyAA.js')),
			__memo(() => import('./chunks/8-m5y35ddp.js'))
		],
		routes: [
			{
				id: "/(app)",
				pattern: /^\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 7 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/configuration","/configuration/__data.json"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set(["/configuration","/configuration/__data.json"]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
