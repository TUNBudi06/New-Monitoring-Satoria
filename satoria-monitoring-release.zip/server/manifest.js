const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.BsJof7AV.js",app:"_app/immutable/entry/app.Bpo_rpMr.js",imports:["_app/immutable/entry/start.BsJof7AV.js","_app/immutable/chunks/C1fdFZsT.js","_app/immutable/chunks/CqgIQq5I.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/BemDnsh9.js","_app/immutable/entry/app.Bpo_rpMr.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/Dk1FCHT_.js","_app/immutable/chunks/o7DcF9Ny.js","_app/immutable/chunks/BemDnsh9.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CqgIQq5I.js","_app/immutable/chunks/B59TdyIj.js","_app/immutable/chunks/BQkGgKpi.js","_app/immutable/chunks/S_BVD0_K.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-DTGlHWJZ.js')),
			__memo(() => import('./chunks/1-C08k-1iB.js')),
			__memo(() => import('./chunks/2-BhoOpyOl.js')),
			__memo(() => import('./chunks/3-BtzdsLM4.js')),
			__memo(() => import('./chunks/7-vUgyEB0Q.js')),
			__memo(() => import('./chunks/8-DXOLJBK1.js')),
			__memo(() => import('./chunks/11-B6anBaxB.js')),
			__memo(() => import('./chunks/12-BEum-8M5.js')),
			__memo(() => import('./chunks/13-CV53gfFE.js')),
			__memo(() => import('./chunks/14-oistu4ze.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-DrZ1n8rI.js'))
		],
		routes: [
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 10 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
