const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.DU5uG3sa.js",app:"_app/immutable/entry/app.B3Hds_hH.js",imports:["_app/immutable/entry/start.DU5uG3sa.js","_app/immutable/chunks/Bf_oARuO.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/D26IJUcv.js","_app/immutable/entry/app.B3Hds_hH.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/B3y5QMs3.js","_app/immutable/chunks/Cn7nNa4a.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/D26IJUcv.js","_app/immutable/chunks/DaoVg8md.js","_app/immutable/chunks/o2QMK_dP.js","_app/immutable/chunks/CFi_j4tm.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-DeCwncRp.js')),
			__memo(() => import('./chunks/1-B0WbknHo.js')),
			__memo(() => import('./chunks/2-BYw80Saq.js')),
			__memo(() => import('./chunks/3-CXgr7MVh.js')),
			__memo(() => import('./chunks/7-CHO-UhR5.js')),
			__memo(() => import('./chunks/8-4QJWYmpN.js')),
			__memo(() => import('./chunks/11-DSpiiVOb.js')),
			__memo(() => import('./chunks/12-DuFB0kJr.js')),
			__memo(() => import('./chunks/13-C0zx4i_t.js')),
			__memo(() => import('./chunks/14-jj_4eGew.js')),
			__memo(() => import('./chunks/15-D9oF7WdP.js'))
		],
		routes: [
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 10 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
