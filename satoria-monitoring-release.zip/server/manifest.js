const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.BEWx5l80.js",app:"_app/immutable/entry/app.BvX-JlT0.js",imports:["_app/immutable/entry/start.BEWx5l80.js","_app/immutable/chunks/DgZxKvym.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/entry/app.BvX-JlT0.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/Ck2fqhG2.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/D1GQsrue.js","_app/immutable/chunks/C5SJzsNr.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-B7tGGm-g.js')),
			__memo(() => import('./chunks/1-DaPQdEft.js')),
			__memo(() => import('./chunks/2-DxdQWAjy.js')),
			__memo(() => import('./chunks/3-DVFLSGul.js')),
			__memo(() => import('./chunks/4-JS1f4uW5.js')),
			__memo(() => import('./chunks/5-B1fLIMeO.js')),
			__memo(() => import('./chunks/6-DBKJSX8m.js')),
			__memo(() => import('./chunks/7-Dz9q4sYu.js')),
			__memo(() => import('./chunks/8-COLmoPH5.js')),
			__memo(() => import('./chunks/9-CYGYlP4c.js')),
			__memo(() => import('./chunks/10-D0SyQbBL.js')),
			__memo(() => import('./chunks/11-BvVJrLGK.js')),
			__memo(() => import('./chunks/12-DxrJBV27.js')),
			__memo(() => import('./chunks/13-CeqElTLP.js')),
			__memo(() => import('./chunks/14-CvjssZ1K.js')),
			__memo(() => import('./chunks/15-DtpjYvYx.js')),
			__memo(() => import('./chunks/16-DqfLWFVk.js')),
			__memo(() => import('./chunks/17-CAzfHN7t.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-BqHgD9y4.js')),
			__memo(() => import('./chunks/19-hzh8e0Lg.js'))
		],
		routes: [
			{
				id: "/(app)",
				pattern: /^\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/account",
				pattern: /^\/account\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(app)/account/admin",
				pattern: /^\/account\/admin\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/account/devices",
				pattern: /^\/account\/devices\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(app)/configuration",
				pattern: /^\/configuration\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2",
				pattern: /^\/configuration\/line2\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/logout",
				pattern: /^\/logout\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/(app)/monitor",
				pattern: /^\/monitor\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2",
				pattern: /^\/monitor\/line2\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 18 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
