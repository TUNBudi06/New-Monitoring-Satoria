const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.DDeChBxU.js",app:"_app/immutable/entry/app.ChIa-lqm.js",imports:["_app/immutable/entry/start.DDeChBxU.js","_app/immutable/chunks/CJnGcTFu.js","_app/immutable/chunks/BMWwaGIr.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/BSnVJNDa.js","_app/immutable/entry/app.ChIa-lqm.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/CYlDMC1d.js","_app/immutable/chunks/CSrnH8IZ.js","_app/immutable/chunks/BSnVJNDa.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/BMWwaGIr.js","_app/immutable/chunks/CJfCnddR.js","_app/immutable/chunks/BZF4576O.js","_app/immutable/chunks/4fFwGPg6.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-BlkehF5d.js')),
			__memo(() => import('./chunks/1-B2hA2XdU.js')),
			__memo(() => import('./chunks/2-CGQeBTC9.js')),
			__memo(() => import('./chunks/3-BWj8fwBZ.js')),
			__memo(() => import('./chunks/7-BYMdNr6C.js')),
			__memo(() => import('./chunks/8-DM-c1M07.js')),
			__memo(() => import('./chunks/11-AYVegD8j.js')),
			__memo(() => import('./chunks/12-CvlAX_ik.js')),
			__memo(() => import('./chunks/13-C2clxTdO.js')),
			__memo(() => import('./chunks/14-D03B17ZF.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/15-B_m__qiq.js'))
		],
		routes: [
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 10 },
				endpoint: null
			}
		],
		prerendered_routes: new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set(["/","/__data.json","/configuration","/configuration/__data.json","/configuration/line2","/configuration/line2/__data.json","/monitor","/monitor/__data.json","/monitor/line2","/monitor/line2/__data.json"]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
