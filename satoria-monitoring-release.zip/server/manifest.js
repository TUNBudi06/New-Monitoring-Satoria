const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"_app/immutable/entry/start.DFj6BZfZ.js",app:"_app/immutable/entry/app.CQDQRhI9.js",imports:["_app/immutable/entry/start.DFj6BZfZ.js","_app/immutable/chunks/DkjyHJ0x.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/entry/app.CQDQRhI9.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/YFp1XVmH.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/B5_kf4jH.js","_app/immutable/chunks/5Qpl9XkE.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./chunks/0-BjNnlzEn.js')),
			__memo(() => import('./chunks/1-eQxNRcgx.js')),
			__memo(() => import('./chunks/2-Bq1yrSox.js')),
			__memo(() => import('./chunks/3-BM0D9qht.js')),
			__memo(() => import('./chunks/4-D-BnsuMj.js')),
			__memo(() => import('./chunks/5-DlY5P2_5.js')),
			__memo(() => import('./chunks/6-BoE-p5it.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/7-ByMSu1MJ.js')),
			__memo(() => import('./chunks/8-Dzm3rEhZ.js')),
			__memo(() => import('./chunks/9-DJpdcv8N.js')),
			__memo(() => import('./chunks/10-C8PdSQ5c.js')),
			__memo(() => import('./chunks/11-CFp-tABx.js')),
			__memo(() => import('./chunks/12-CwCm65AE.js')),
			__memo(() => import('./chunks/13-CsQAsaex.js')),
			__memo(() => import('./chunks/14-CGmhPoEQ.js')),
			__memo(() => import('./chunks/15-JP74Xg-M.js')),
			__memo(() => import('./chunks/16-JKLEkt0Q.js')),
			__memo(() => import('./chunks/17-p34a0egq.js').then(function (n) { return n._; })),
			__memo(() => import('./chunks/18-BJKkvp_L.js')),
			__memo(() => import('./chunks/19-6QEy7UJT.js'))
		],
		routes: [
			{
				id: "/(app)",
				pattern: /^\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/(app)/account",
				pattern: /^\/account\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 5 },
				endpoint: null
			},
			{
				id: "/(app)/account/admin",
				pattern: /^\/account\/admin\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 6 },
				endpoint: null
			},
			{
				id: "/(app)/account/devices",
				pattern: /^\/account\/devices\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 7 },
				endpoint: null
			},
			{
				id: "/(app)/configuration",
				pattern: /^\/configuration\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 8 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2",
				pattern: /^\/configuration\/line2\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 9 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu102",
				pattern: /^\/configuration\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 10 },
				endpoint: null
			},
			{
				id: "/(app)/configuration/line2/ahu103",
				pattern: /^\/configuration\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 11 },
				endpoint: null
			},
			{
				id: "/(login)/forgot",
				pattern: /^\/forgot\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 16 },
				endpoint: null
			},
			{
				id: "/(login)/login",
				pattern: /^\/login\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 17 },
				endpoint: null
			},
			{
				id: "/logout",
				pattern: /^\/logout\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 19 },
				endpoint: null
			},
			{
				id: "/(app)/monitor",
				pattern: /^\/monitor\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 12 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2",
				pattern: /^\/monitor\/line2\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 13 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu102",
				pattern: /^\/monitor\/line2\/ahu102\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 14 },
				endpoint: null
			},
			{
				id: "/(app)/monitor/line2/ahu103",
				pattern: /^\/monitor\/line2\/ahu103\/?$/,
				params: [],
				page: { layouts: [0,2,], errors: [1,,], leaf: 15 },
				endpoint: null
			},
			{
				id: "/(login)/register",
				pattern: /^\/register\/?$/,
				params: [],
				page: { layouts: [0,3,], errors: [1,,], leaf: 18 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

const prerendered = new Set([]);

const base = "";

export { base, manifest, prerendered };
//# sourceMappingURL=manifest.js.map
