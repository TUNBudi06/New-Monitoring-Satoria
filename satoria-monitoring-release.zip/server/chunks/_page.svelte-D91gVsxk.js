import { p as push, e as pop, j as ensure_array_like, q as escape_html } from './index2-OytlP0AJ.js';
import { C as Card, a as Card_header, b as Card_content } from './card-header-ChuvZucj.js';
import { C as Card_description } from './card-description-DeYd_h0t.js';
import { C as Card_title } from './card-title-CjR6TAaq.js';
import { g as getCoreRowModel } from './index-B79SqP-N.js';
import { c as createSvelteTable, T as Table, a as Table_header, d as Table_body, b as Table_row, e as Table_head, f as Table_cell, r as renderComponent, g as renderSnippet, F as Flex_render } from './table-row-BeBs-FJC.js';
import { z } from 'zod';
import { B as Button } from './button-CK6IyQZt.js';
import './badge-Cb0zvQS5.js';
import './Toaster.svelte_svelte_type_style_lang-BjAwpewE.js';
import './utils-B85LEA7R.js';
import './index-server-DH7p7JOq.js';

function createRawSnippet(fn) {
  return (payload, ...args) => {
    var getters = (
      /** @type {Getters<Params>} */
      args.map((value) => () => value)
    );
    payload.out += fn(...getters).render().trim();
  };
}
function Data_Table($$payload, $$props) {
  push();
  let { data, columns: columns2 } = $$props;
  const table = createSvelteTable({
    get data() {
      return data;
    },
    columns: columns2,
    getCoreRowModel: getCoreRowModel()
  });
  $$payload.out += `<div class="rounded-md border"><!---->`;
  Table($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Table_header($$payload2, {
        children: ($$payload3) => {
          const each_array = ensure_array_like(table.getHeaderGroups());
          $$payload3.out += `<!--[-->`;
          for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
            let headerGroup = each_array[$$index_1];
            $$payload3.out += `<!---->`;
            Table_row($$payload3, {
              children: ($$payload4) => {
                const each_array_1 = ensure_array_like(headerGroup.headers);
                $$payload4.out += `<!--[-->`;
                for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
                  let header = each_array_1[$$index];
                  $$payload4.out += `<!---->`;
                  Table_head($$payload4, {
                    children: ($$payload5) => {
                      if (!header.isPlaceholder) {
                        $$payload5.out += "<!--[-->";
                        Flex_render($$payload5, {
                          content: header.column.columnDef.header,
                          context: header.getContext()
                        });
                      } else {
                        $$payload5.out += "<!--[!-->";
                      }
                      $$payload5.out += `<!--]-->`;
                    },
                    $$slots: { default: true }
                  });
                  $$payload4.out += `<!---->`;
                }
                $$payload4.out += `<!--]-->`;
              },
              $$slots: { default: true }
            });
            $$payload3.out += `<!---->`;
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <!---->`;
      Table_body($$payload2, {
        children: ($$payload3) => {
          const each_array_2 = ensure_array_like(table.getRowModel().rows);
          if (each_array_2.length !== 0) {
            $$payload3.out += "<!--[-->";
            for (let $$index_3 = 0, $$length = each_array_2.length; $$index_3 < $$length; $$index_3++) {
              let row = each_array_2[$$index_3];
              $$payload3.out += `<!---->`;
              Table_row($$payload3, {
                "data-state": row.getIsSelected() && "selected",
                children: ($$payload4) => {
                  const each_array_3 = ensure_array_like(row.getVisibleCells());
                  $$payload4.out += `<!--[-->`;
                  for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
                    let cell = each_array_3[$$index_2];
                    $$payload4.out += `<!---->`;
                    Table_cell($$payload4, {
                      children: ($$payload5) => {
                        Flex_render($$payload5, {
                          content: cell.column.columnDef.cell,
                          context: cell.getContext()
                        });
                      },
                      $$slots: { default: true }
                    });
                    $$payload4.out += `<!---->`;
                  }
                  $$payload4.out += `<!--]-->`;
                },
                $$slots: { default: true }
              });
              $$payload3.out += `<!---->`;
            }
          } else {
            $$payload3.out += "<!--[!-->";
            $$payload3.out += `<!---->`;
            Table_row($$payload3, {
              children: ($$payload4) => {
                $$payload4.out += `<!---->`;
                Table_cell($$payload4, {
                  colspan: columns2.length,
                  class: "h-24 text-center",
                  children: ($$payload5) => {
                    $$payload5.out += `<!---->No results.`;
                  },
                  $$slots: { default: true }
                });
                $$payload4.out += `<!---->`;
              },
              $$slots: { default: true }
            });
            $$payload3.out += `<!---->`;
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div>`;
  pop();
}
function Actions_Session($$payload, $$props) {
  push();
  let { row } = $$props;
  {
    $$payload.out += "<!--[!-->";
    Button($$payload, {
      variant: "default",
      Disabled: true,
      children: ($$payload2) => {
        $$payload2.out += `<!---->Current Device`;
      },
      $$slots: { default: true }
    });
  }
  $$payload.out += `<!--]-->`;
  pop();
}
function BadgeTable($$payload, $$props) {
  push();
  let { type, now } = $$props;
  if (now) {
    $$payload.out += "<!--[-->";
    {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]-->`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<span>${escape_html(type)}</span>`;
  }
  $$payload.out += `<!--]-->`;
  pop();
}
z.object({
  id: z.string(),
  token: z.string(),
  type: z.enum(["desktop", "smartphone"]),
  address: z.string(),
  now: z.boolean(),
  last_activity: z.date()
});
const columns = [
  {
    accessorKey: "id",
    header: "ID"
  },
  {
    accessorKey: "type",
    header: "Device",
    cell: ({ row }) => {
      const type = row.getValue("type");
      const now = row.original.now;
      return renderComponent(BadgeTable, { type, now });
    }
  },
  {
    accessorKey: "address",
    header: "Network Addr"
  },
  {
    accessorKey: "last_activity",
    header: "Last Activity",
    cell: ({ row }) => {
      const getdate = row.getValue("last_activity");
      const snippet = createRawSnippet((date) => {
        const d = date();
        return {
          render: () => {
            return `<span>${d.toLocaleDateString("en-US", { weekday: "short" })}, ${d.toLocaleDateString()} ${d.toLocaleTimeString()}</span>`;
          }
        };
      });
      return renderSnippet(snippet, getdate);
    }
  },
  {
    id: "actions",
    header: "Actions",
    cell: ({ row }) => {
      return renderComponent(Actions_Session, { row: row.original });
    }
  }
];
function _page($$payload, $$props) {
  push();
  let { data, form } = $$props;
  $$payload.out += `<!---->`;
  Card($$payload, {
    class: "h-full max-h-[91vh] w-full",
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Card_header($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card_title($$payload3, {
            children: ($$payload4) => {
              $$payload4.out += `<!---->Devices`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <!---->`;
          Card_description($$payload3, {
            children: ($$payload4) => {
              $$payload4.out += `<!---->List of devices that are currently logged in to your account.`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <!---->`;
      Card_content($$payload2, {
        class: "grid gap-4 overflow-y-auto",
        children: ($$payload3) => {
          $$payload3.out += `<p class="text-muted-foreground">This page shows all devices that are currently logged in to your account. You can log out of
			any device at any time.</p> `;
          Data_Table($$payload3, { columns, data: data.sessionDevice });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!---->`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-D91gVsxk.js.map
