const DATABASE_URL = "postgres://root:mysecretpassword@localhost:5432/local";
const JWT_ALGORITHM = "HS512";
const SESSION_REMEMBER = "30";
const REFRESH_REMEMBER = "15m";
const PRIVATE_JWT_SECRET = "AhSy0PhSL2WkU7Yw4xbKEApR48+XJMqJ8y7X3CETqBmUDfsdtaAFKF/kH+6enJAKnx/koGlu2f1Vl2FIOwVeEw==";
const COOKIE_MAX_AGE = "94608000";

export { COOKIE_MAX_AGE as C, DATABASE_URL as D, JWT_ALGORITHM as J, PRIVATE_JWT_SECRET as P, REFRESH_REMEMBER as R, SESSION_REMEMBER as S };
//# sourceMappingURL=private-DXaAhYwL.js.map
