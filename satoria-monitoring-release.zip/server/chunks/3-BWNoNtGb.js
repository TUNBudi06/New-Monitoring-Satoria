const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-69ylWwuL.js')).default;
const imports = ["_app/immutable/nodes/3.CPV9xCOr.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/CiXAj25e.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/CxJc_Azy.js","_app/immutable/chunks/Dk72urO7.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-BWNoNtGb.js.map
