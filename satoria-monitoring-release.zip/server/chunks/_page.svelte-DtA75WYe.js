import { p as push, e as pop } from './index2-C_y23GpV.js';
import { C as Card, a as Card_header, b as Card_content } from './card-header-BRYX2G23.js';
import { C as Card_title } from './card-title-BhIXASx0.js';
import './utils-zdf1KThM.js';

function _page($$payload, $$props) {
  push();
  $$payload.out += `<!---->`;
  Card($$payload, {
    class: "w-full",
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Card_header($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card_title($$payload3, {
            class: "w-full text-center text-2xl font-bold",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Configuration Line 2 Air Handling Unit 102`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <!---->`;
      Card_content($$payload2, {
        children: ($$payload3) => {
          {
            $$payload3.out += "<!--[!-->";
            $$payload3.out += `<p class="text-muted-foreground text-center">Loading...</p>`;
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!---->`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DtA75WYe.js.map
