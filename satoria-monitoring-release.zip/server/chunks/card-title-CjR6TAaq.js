import { p as push, k as spread_attributes, l as clsx, u as bind_props, e as pop } from './index2-OytlP0AJ.js';
import { c as cn } from './utils-B85LEA7R.js';

function Card_title($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out += `<div${spread_attributes(
    {
      "data-slot": "card-title",
      class: clsx(cn("leading-none font-semibold", className)),
      ...restProps
    },
    null
  )}>`;
  children?.($$payload);
  $$payload.out += `<!----></div>`;
  bind_props($$props, { ref });
  pop();
}

export { Card_title as C };
//# sourceMappingURL=card-title-CjR6TAaq.js.map
