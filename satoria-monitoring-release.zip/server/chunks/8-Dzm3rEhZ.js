const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-dbQckiWm.js')).default;
const imports = ["_app/immutable/nodes/8.BM71cQm9.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B41hdK34.js","_app/immutable/chunks/D5X3AARZ.js","_app/immutable/chunks/BGx13tzy.js","_app/immutable/chunks/jOYcctrt.js","_app/immutable/chunks/DkjyHJ0x.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/CCAte5Uw.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js","_app/immutable/chunks/BDwlTwo-.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/DE8lGZ2d.js","_app/immutable/chunks/CNDr1Z7s.js","_app/immutable/chunks/BdMBCV5W.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-Dzm3rEhZ.js.map
