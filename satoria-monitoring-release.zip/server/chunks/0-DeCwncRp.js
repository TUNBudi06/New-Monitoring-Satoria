const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-0yB81X2U.js')).default;
const imports = ["_app/immutable/nodes/0.nKeH-3W7.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/niT0dDKO.js"];
const stylesheets = ["_app/immutable/assets/0.CcNb2HGS.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-DeCwncRp.js.map
