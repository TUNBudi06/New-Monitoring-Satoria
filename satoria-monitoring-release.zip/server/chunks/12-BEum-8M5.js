const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CPWFt9j8.js')).default;
const imports = ["_app/immutable/nodes/12.CXaUo1si.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/DuSXapKN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=12-BEum-8M5.js.map
