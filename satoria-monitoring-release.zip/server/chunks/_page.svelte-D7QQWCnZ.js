import { p as push, x as copy_payload, y as assign_payload, e as pop } from './index2-DUnQqHl4.js';
import './button-C5sHZXZh.js';
import { s as superForm, z as zodClient, e as emailSchema, u as usernameSchema } from './14-oistu4ze.js';
import './client-4wmd_MHx.js';
import './index-DwrKR0Y-.js';
import './Toaster.svelte_svelte_type_style_lang-DHk6apEn.js';
import './utils-kqvSmeHv.js';
import 'zod';
import './exports-Bob2A8Cd.js';
import './index-server2-CE04Q_O7.js';
import './_commonjsHelpers-B85MJLTf.js';
import './stringify-nj1_0ECd.js';
import './index4-DfyHg8Ez.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'drizzle-orm';
import 'bcrypt';
import 'crypto';
import './index-server-DH7p7JOq.js';

function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  superForm(data.email, { validators: zodClient(emailSchema) });
  superForm(data.username, { validators: zodClient(usernameSchema) });
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="flex flex-col gap-6">`;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> <div class="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">By clicking Login, you agree to our <a href="/">Terms of Service</a> and <a href="##">Privacy Policy</a>.</div></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-D7QQWCnZ.js.map
