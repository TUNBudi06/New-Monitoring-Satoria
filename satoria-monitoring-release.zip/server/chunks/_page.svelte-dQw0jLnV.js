import { p as push, q as copy_payload, t as assign_payload, e as pop } from './index2-DhlZV1j8.js';
import './button-DnIlmaJV.js';
import { s as superForm, z as zodClient, e as emailSchema, u as usernameSchema } from './14-D03B17ZF.js';
import './client-Dd5cuolM.js';
import './index-DwrKR0Y-.js';
import './utils-BS0-NKpy.js';
import 'zod';
import './exports-D-T8R0wX.js';
import './index-server-DjdD3RRd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './stringify-nj1_0ECd.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'drizzle-orm';
import 'bcrypt';
import 'crypto';

function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  superForm(data.email, { validators: zodClient(emailSchema) });
  superForm(data.username, { validators: zodClient(usernameSchema) });
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="flex flex-col gap-6">`;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> <div class="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">By clicking Login, you agree to our <a href="/">Terms of Service</a> and <a href="##">Privacy Policy</a>.</div></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-dQw0jLnV.js.map
