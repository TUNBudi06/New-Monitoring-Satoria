const index = 14;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CPWFt9j8.js')).default;
const imports = ["_app/immutable/nodes/14.CfVmJ1IJ.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B41hdK34.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=14-CGmhPoEQ.js.map
