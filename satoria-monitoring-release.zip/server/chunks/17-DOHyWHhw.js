const index = 17;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BgZlqRDj.js')).default;
const imports = ["_app/immutable/nodes/17.BDJKaFFW.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/83YYTNZR.js","_app/immutable/chunks/Wq0LeURr.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/897_qMa7.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=17-DOHyWHhw.js.map
