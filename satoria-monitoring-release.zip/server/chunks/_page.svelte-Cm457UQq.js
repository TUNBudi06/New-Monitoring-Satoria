import { C as Card, a as Card_header, c as Card_title, b as Card_content } from './card-title-BfjW5JWC.js';
import './index2-DhlZV1j8.js';
import './utils-BS0-NKpy.js';

function _page($$payload) {
  $$payload.out += `<div class="flex flex-col gap-6">`;
  Card($$payload, {
    children: ($$payload2) => {
      Card_header($$payload2, {
        class: "text-center",
        children: ($$payload3) => {
          Card_title($$payload3, {
            class: "text-xl",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Dont Support for now`;
            },
            $$slots: { default: true }
          });
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Card_content($$payload2, {
        class: "text-center",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Currently doesnt support this reset password try contacting your admin`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div>`;
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cm457UQq.js.map
