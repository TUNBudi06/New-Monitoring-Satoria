const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Dr0OiJAN.js')).default;
const imports = ["_app/immutable/nodes/3.DL1b3D4P.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/DMzBSWS0.js","_app/immutable/chunks/D-A_H2yJ.js","_app/immutable/chunks/DDrWc_4L.js","_app/immutable/chunks/je7EIwxK.js","_app/immutable/chunks/BTTR7cSe.js","_app/immutable/chunks/CvhWP5Ll.js","_app/immutable/chunks/CnZN1hIZ.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-C8t8Vq9u.js.map
