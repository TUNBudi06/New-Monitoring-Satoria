import { p as push, w as copy_payload, x as assign_payload, e as pop, k as spread_attributes, l as clsx, u as bind_props } from './index2-OytlP0AJ.js';
import { C as Card, a as Card_header, b as Card_content } from './card-header-ChuvZucj.js';
import { C as Card_footer } from './card-footer-DVRmkmSl.js';
import './button-CK6IyQZt.js';
import { e as emailSchema, u as usernameSchema } from './17-p34a0egq.js';
import './client-BYfstKI-.js';
import { b as superForm, c as zodClient } from './zod-B9fgBnn4.js';
import './index-DHSpIlkf.js';
import './Toaster.svelte_svelte_type_style_lang-BjAwpewE.js';
import { c as cn } from './utils-B85LEA7R.js';
import 'zod';
import './index4-Bq3YGG3j.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';
import 'drizzle-orm';
import 'bcrypt';
import 'crypto';
import './exports-Ch6SmBKb.js';
import './index-server2-X77dWp9g.js';
import './stringify-nj1_0ECd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './index-server-DH7p7JOq.js';

function Skeleton($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out += `<div${spread_attributes(
    {
      "data-slot": "skeleton",
      class: clsx(cn("bg-accent animate-pulse rounded-md", className)),
      ...restProps
    },
    null
  )}></div>`;
  bind_props($$props, { ref });
  pop();
}
function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  superForm(data.email, { validators: zodClient(emailSchema) });
  superForm(data.username, { validators: zodClient(usernameSchema) });
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="flex flex-col gap-6">`;
    {
      $$payload2.out += "<!--[!-->";
      $$payload2.out += `<!---->`;
      Card($$payload2, {
        class: "space-y-4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card_header($$payload3, {
            children: ($$payload4) => {
              Skeleton($$payload4, { class: "h-6 w-32" });
              $$payload4.out += `<!----> `;
              Skeleton($$payload4, { class: "h-4 w-full max-w-[200px]" });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <!---->`;
          Card_content($$payload3, {
            class: "space-y-3",
            children: ($$payload4) => {
              Skeleton($$payload4, { class: "h-9 w-full" });
              $$payload4.out += `<!----> `;
              Skeleton($$payload4, { class: "h-9 w-full" });
              $$payload4.out += `<!----> `;
              Skeleton($$payload4, { class: "h-4 w-3/4" });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <!---->`;
          Card_footer($$payload3, {
            children: ($$payload4) => {
              Skeleton($$payload4, { class: "h-10 w-full rounded" });
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    }
    $$payload2.out += `<!--]--> <div class="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">By clicking Login, you agree to our <a href="/">Terms of Service</a> and <a href="##">Privacy Policy</a>.</div></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-B9iTKnWS.js.map
