const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BZTUT2Yf.js')).default;
const imports = ["_app/immutable/nodes/11.CXaUo1si.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/DuSXapKN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=11-B6anBaxB.js.map
