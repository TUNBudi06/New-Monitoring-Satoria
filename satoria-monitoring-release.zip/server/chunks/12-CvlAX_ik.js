const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CPWFt9j8.js')).default;
const imports = ["_app/immutable/nodes/12.BMFT7JIU.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/B3uzrfl-.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=12-CvlAX_ik.js.map
