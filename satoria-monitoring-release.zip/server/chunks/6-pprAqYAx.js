import { d as db, u as users } from './index4-D0Nb1HJJ.js';
import { z } from 'zod';
import { c as createColumnHelper, r as renderComponent } from './render-helpers-BoMdKG-p.js';
import { s as setContext, p as push, e as pop, g as getContext } from './index2-C_y23GpV.js';
import './button-D_a_uBj6.js';
import './client-Chw5mV5o.js';
import { s as superValidate, z as zod, m as message, a as setError } from './zod-CwoAiKG0.js';
import { f as fail } from './index-DHSpIlkf.js';
import { eq, or, desc, asc } from 'drizzle-orm';
import * as crypto from 'crypto';
import bcrypt__default__default from 'bcrypt';

const keyDAS = Symbol("devices-admin-store");
const keyUserContext = Symbol("user-context");
const getDevicesAdminStore = () => {
  return getContext(keyDAS);
};
const setDevicesAdminStore = (store) => {
  setContext(keyDAS, store);
};
const setUserIdContext = async (id) => {
  setContext(keyUserContext, id);
};
const getUserIdContext = () => {
  return getContext(keyUserContext);
};
function Actions_row($$payload, $$props) {
  push();
  let { row } = $$props;
  getDevicesAdminStore();
  getUserIdContext();
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  pop();
}
const UserZodObject = z.object({
  username: z.string().min(1, "Username is required"),
  firstname: z.string().min(1, "First name is required"),
  lastname: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirm_password: z.string().min(6, "Confirm password must be at least 6 characters"),
  role: z.enum(["user", "admin"]).default("user"),
  job_title: z.string()
});
const FormChangePasswordZodObject = z.object({
  id: z.number().nullable(),
  new_password: z.string().min(6, "New password must be at least 6 characters"),
  confirm_password: z.string().min(6, "Confirm password must be at least 6 characters")
});
const FormDeleteZodObject = z.object({
  id: z.number().nullable()
});
const FormChangeAccountZodObject = z.object({
  userId: z.number().nullable(),
  username: z.string().min(1, "Username is required"),
  email: z.string().email("Invalid email address")
});
const columnHelper = createColumnHelper();
const ColumnsFormat = [
  columnHelper.accessor("id", {
    header: "ID",
    cell: (info) => info.getValue().toString(),
    size: 50
  }),
  columnHelper.accessor("username", {
    header: "Username",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("firstname", {
    header: "First Name",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("lastname", {
    header: "Last Name",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("email", {
    header: "Email",
    cell: (info) => info.getValue(),
    size: 200
  }),
  columnHelper.accessor("role", {
    header: "Role",
    cell: (info) => info.getValue(),
    size: 100
  }),
  columnHelper.accessor("job_title", {
    header: "Job Title",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("createdAt", {
    header: "Created At",
    cell: (info) => info.getValue().toLocaleString(),
    size: 200
  }),
  columnHelper.accessor("updatedAt", {
    header: "Updated At",
    cell: (info) => info.getValue()?.toLocaleString() || "N/A",
    size: 200
  }),
  columnHelper.accessor("deletedAt", {
    header: "Deleted At",
    cell: (info) => info.getValue()?.toLocaleString() || "N/A",
    size: 200
  }),
  columnHelper.display({
    id: "actions",
    header: "Actions",
    size: 150,
    cell: ({ row }) => {
      return renderComponent(Actions_row, { row });
    }
  })
];

async function formGen() {
  return await Promise.all([
    await superValidate(zod(UserZodObject)),
    await superValidate(zod(FormChangeAccountZodObject)),
    await superValidate(zod(FormChangePasswordZodObject)),
    await superValidate(zod(FormDeleteZodObject))
  ]);
}
const load = async (event) => {
  const [AA, CC, CP, FD] = await Promise.all([...await formGen()]);
  const userJWT = event.locals.jwt.decode(event.cookies.get("refresh_token") || "");
  return {
    userJWT,
    users: db.select().from(users).orderBy(desc(users.username), asc(users.deletedAt)),
    formAA: AA,
    formCC: CC,
    formCP: CP,
    formD: FD
  };
};
const actions = {
  create: async (event) => {
    const form = await superValidate(event, zod(UserZodObject));
    if (!form.valid) {
      const [, CC, CP, FD] = await formGen();
      return fail(400, {
        formAA: form,
        formCC: CC,
        formCP: CP,
        formD: FD,
        form
      });
    }
    if (!form.data.password || form.data.password !== form.data.confirm_password) {
      setError(form, "password", "Password and confirm password must match");
      return setError(form, "confirm_password", "Password and confirm password must match");
    }
    const ifAlreadyExists = await db.$count(
      users,
      or(eq(users.username, form.data.username), eq(users.email, form.data.email))
    );
    if (ifAlreadyExists > 0) {
      setError(form, "email", "Username or email already exists");
      return setError(form, "username", "Username or email already exists");
    }
    const hashPassword = await bcrypt__default__default.hash(form.data.password, 12);
    await db.insert(users).values({
      username: form.data.username,
      firstname: form.data.firstname,
      lastname: form.data.lastname,
      email: form.data.email,
      password: hashPassword,
      role: form.data.role,
      job_title: form.data.job_title,
      rememberMe: crypto.randomBytes(32).toString("base64url")
    });
    return message(form, "User created successfully");
  },
  changeCredential: async (event) => {
    const form = await superValidate(event, zod(FormChangeAccountZodObject));
    if (!form.valid) {
      const [AA, , CP, FD] = await formGen();
      return fail(400, {
        formAA: AA,
        formCC: form,
        formCP: CP,
        formD: FD
      });
    }
    console.log(await form.data);
    await db.update(users).set({ username: form.data.username, email: form.data.email, updatedAt: /* @__PURE__ */ new Date() }).where(eq(users.id, Number(form.data.userId)));
    return message(form, "User credentials updated successfully");
  },
  changePassword: async (event) => {
    const form = await superValidate(event, zod(FormChangePasswordZodObject));
    if (!form.valid) {
      const [AA, CC, , FD] = await formGen();
      return fail(400, {
        formAA: AA,
        formCC: CC,
        formCP: form,
        formD: FD
      });
    }
    if (form.data.new_password !== form.data.confirm_password) {
      setError(form, "new_password", "Password and confirm password must match");
      return setError(form, "confirm_password", "Password and confirm password must match");
    }
    const hashPassword = await bcrypt__default__default.hash(form.data.new_password, 12);
    await db.update(users).set({ password: hashPassword, updatedAt: /* @__PURE__ */ new Date() }).where(eq(users.id, Number(form.data.id)));
    return message(form, "User password updated successfully");
  },
  DeleteAccount: async (event) => {
    const form = await superValidate(event, zod(FormDeleteZodObject));
    if (!form.valid) {
      const [AA, CC, CP] = await formGen();
      return fail(400, {
        formAA: AA,
        formCC: CC,
        formCP: CP,
        formD: form
      });
    }
    await db.update(users).set({ deletedAt: /* @__PURE__ */ new Date() }).where(eq(users.id, Number(form.data.id)));
    return message(form, "User deleted successfully");
  },
  UnDeleteAccount: async (event) => {
    const form = await superValidate(event, zod(FormDeleteZodObject));
    if (!form.valid) {
      const [AA, CC, CP] = await formGen();
      return fail(400, {
        formAA: AA,
        formCC: CC,
        formCP: CP,
        formD: form
      });
    }
    console.log(form.data);
    await db.update(users).set({ deletedAt: null }).where(eq(users.id, Number(form.data.id)));
    return message(form, "User restored successfully");
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-uKorrxkk.js')).default;
const server_id = "src/routes/(app)/account/admin/+page.server.ts";
const imports = ["_app/immutable/nodes/6.B_iRLNCP.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/CBBX3viM.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/Wq0LeURr.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DktTnN65.js","_app/immutable/chunks/DUTBo3uO.js","_app/immutable/chunks/B1LArVJB.js","_app/immutable/chunks/DxvS11ZK.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/hOen_43f.js","_app/immutable/chunks/CsX36sAN.js","_app/immutable/chunks/DzYA0N7_.js","_app/immutable/chunks/CxJc_Azy.js","_app/immutable/chunks/Dk72urO7.js","_app/immutable/chunks/zUc9I7b_.js","_app/immutable/chunks/B3qc7meF.js","_app/immutable/chunks/Bc0mjKXN.js","_app/immutable/chunks/CC6ZDRYa.js","_app/immutable/chunks/Dnf__lyf.js","_app/immutable/chunks/BMvp3DJu.js","_app/immutable/chunks/83YYTNZR.js","_app/immutable/chunks/Cg1X0_6c.js","_app/immutable/chunks/AHF_-eWw.js","_app/immutable/chunks/CNvlm4iD.js","_app/immutable/chunks/CUdRkPKR.js","_app/immutable/chunks/CoA8UIRm.js"];
const stylesheets = [];
const fonts = [];

var _6 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  server: _page_server_ts,
  server_id: server_id,
  stylesheets: stylesheets
});

export { ColumnsFormat as C, _6 as _, setUserIdContext as a, setDevicesAdminStore as s };
//# sourceMappingURL=6-pprAqYAx.js.map
