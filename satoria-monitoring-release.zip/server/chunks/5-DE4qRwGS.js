import './client-Chw5mV5o.js';
import { s as superValidate, a as setError, m as message } from './memoize-4dA32NW1.js';
import { f as fail } from './index-DHSpIlkf.js';
import 'zod';
import { z as zod } from './zod4-DuqeCOVW.js';
import { z } from 'zod/v4';
import { d as db, u as users } from './index4-CQhZZcHY.js';
import deviceDetector from 'node-device-detector';
import { eq } from 'drizzle-orm';
import bcrypt__default__default from 'bcrypt';
import './exports-DJ-e4XgW.js';
import './index2-C_y23GpV.js';
import './index-server-DpxecShX.js';
import './app-8Apsod8E.js';
import './_commonjsHelpers-B85MJLTf.js';
import 'zod/v4/core';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-DXaAhYwL.js';

const userSchemaName = z.object({
  firstname: z.string().min(1).max(100),
  lastname: z.string().min(1).max(100)
});
z.object({
  email: z.email(),
  username: z.string().min(1).max(100)
});
const userSchemaPassword = z.object({
  old_password: z.string().min(6, "Old Password must be at least 6 characters"),
  new_Password: z.string().min(6, "New Password must be at least 6 characters"),
  new_confirmPassword: z.string().min(6, "Confirm Password must be at least 6 characters")
});

function userPromise(event) {
  const { cookies, locals } = event;
  return new Promise((resolve, reject) => {
    const jwt = locals.jwt.decode(cookies.get("refresh_token") || "");
    if (jwt) {
      resolve(jwt);
    } else {
      reject("cant be found");
    }
  }).then((jwt_string) => {
    return db.select().from(users).where(eq(users.id, jwt_string?.user_id)).then((res) => res[0]);
  });
}
const load = async (event) => {
  const user = await userPromise(event);
  const [names, password, device] = await Promise.all([
    superValidate(user, zod(userSchemaName)),
    superValidate(zod(userSchemaPassword)),
    new deviceDetector().detect(event.request.headers.get("user-agent") || "")
  ]);
  return {
    names,
    password,
    device
  };
};
const actions = {
  UpdateName: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaName));
    const user = await userPromise(event);
    if (!form.valid) {
      const [password, device] = await Promise.all([
        superValidate(zod(userSchemaPassword)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names: form,
        password,
        device
      });
    }
    await db.update(users).set({
      firstname: form.data.firstname,
      lastname: form.data.lastname
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your name");
  },
  UpdatePassword: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaPassword));
    const user = await userPromise(event);
    if (!form.valid) {
      const [names, device] = await Promise.all([
        superValidate(user, zod(userSchemaName)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names,
        password: form,
        device
      });
    }
    if (form.data.new_Password !== form.data.new_confirmPassword) {
      return setError(
        form,
        "new_confirmPassword",
        "New Password and Confirm Password do not match"
      );
    }
    if (!await bcrypt__default__default.compare(form.data.old_password, user.password)) {
      return setError(form, "old_password", "Old Password is incorrect");
    }
    const password = await bcrypt__default__default.hash(form.data.new_Password, 12);
    await db.update(users).set({
      password
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your password");
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BrQzwGU1.js')).default;
const server_id = "src/routes/(app)/account/+page.server.ts";
const imports = ["_app/immutable/nodes/5.Cw0DcsLv.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/Wq0LeURr.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DktTnN65.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/C92kijqc.js","_app/immutable/chunks/DF7EeHcX.js","_app/immutable/chunks/BMvp3DJu.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/DUTBo3uO.js","_app/immutable/chunks/B3qc7meF.js","_app/immutable/chunks/83YYTNZR.js","_app/immutable/chunks/CaXNUFM6.js","_app/immutable/chunks/B-s_29XE.js","_app/immutable/chunks/Dr2NVUXB.js","_app/immutable/chunks/PkzXZsaV.js","_app/immutable/chunks/CUdRkPKR.js","_app/immutable/chunks/CvlZlbrB.js","_app/immutable/chunks/rXV2bYmN.js","_app/immutable/chunks/BXb5CDMn.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=5-DE4qRwGS.js.map
