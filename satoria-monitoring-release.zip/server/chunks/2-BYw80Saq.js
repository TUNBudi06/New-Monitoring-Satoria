const load = async ({ locals }) => {
  return {
    user: "budi"
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-D3pkoVAK.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.Tx37B2fp.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/niT0dDKO.js","_app/immutable/chunks/o2QMK_dP.js","_app/immutable/chunks/Da_yRHvE.js","_app/immutable/chunks/Cn7nNa4a.js","_app/immutable/chunks/CFi_j4tm.js","_app/immutable/chunks/B3y5QMs3.js","_app/immutable/chunks/DaoVg8md.js","_app/immutable/chunks/CClvMc89.js","_app/immutable/chunks/f0AS_gFo.js","_app/immutable/chunks/Dmsp1KAm.js","_app/immutable/chunks/D26IJUcv.js","_app/immutable/chunks/CsdQt_zL.js","_app/immutable/chunks/D_SqPuG1.js","_app/immutable/chunks/Bf_oARuO.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-BYw80Saq.js.map
