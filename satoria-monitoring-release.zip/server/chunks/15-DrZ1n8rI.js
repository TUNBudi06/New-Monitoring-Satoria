const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bmz5UYUx.js')).default;
const imports = ["_app/immutable/nodes/15.htv0ZUSR.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/DuSXapKN.js","_app/immutable/chunks/BtbHRSZ0.js","_app/immutable/chunks/BZDqfNkc.js","_app/immutable/chunks/o7DcF9Ny.js","_app/immutable/chunks/BemDnsh9.js","_app/immutable/chunks/B59TdyIj.js","_app/immutable/chunks/S_BVD0_K.js","_app/immutable/chunks/DHUvJQCu.js","_app/immutable/chunks/Cr4JvKKA.js","_app/immutable/chunks/BdBFO2Uu.js","_app/immutable/chunks/CO_6s0Jq.js","_app/immutable/chunks/BQkGgKpi.js","_app/immutable/chunks/oDtILzwk.js","_app/immutable/chunks/Bg6RrkCw.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-DrZ1n8rI.js.map
