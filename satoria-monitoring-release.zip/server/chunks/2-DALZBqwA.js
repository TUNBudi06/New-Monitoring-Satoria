import { d as db, u as users } from './index4-CQhZZcHY.js';
import { eq } from 'drizzle-orm';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-DXaAhYwL.js';

const load = async (event) => {
  const jwt_cookie = event.cookies.get("refresh_token");
  let user;
  try {
    const payload = event.locals.jwt.decode(jwt_cookie);
    user = await db.select({
      username: users.username,
      email: users.email,
      firstname: users.firstname,
      lastname: users.lastname,
      type: users.role
    }).from(users).where(eq(users.id, payload.user_id)).limit(1).then((res) => res[0]);
  } catch (e) {
    console.error("JWT decode error:", e);
  }
  return {
    user: user || null
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-zWVK7L_l.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.BVybG5xr.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/B3qc7meF.js","_app/immutable/chunks/BJlwnpKT.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/DzYA0N7_.js","_app/immutable/chunks/CxJc_Azy.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/Dk72urO7.js","_app/immutable/chunks/N2eanvh1.js","_app/immutable/chunks/BRG1_Cln.js","_app/immutable/chunks/BXb5CDMn.js","_app/immutable/chunks/DUTBo3uO.js","_app/immutable/chunks/DOfq6C6-.js","_app/immutable/chunks/DF7EeHcX.js","_app/immutable/chunks/CiXAj25e.js","_app/immutable/chunks/BkmGgzMo.js","_app/immutable/chunks/zUc9I7b_.js","_app/immutable/chunks/88HccgOR.js","_app/immutable/chunks/lOueDxZy.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-DALZBqwA.js.map
