const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BZTUT2Yf.js')).default;
const imports = ["_app/immutable/nodes/11.DR3Ib5gL.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/DHUAlugP.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=11-DSpiiVOb.js.map
