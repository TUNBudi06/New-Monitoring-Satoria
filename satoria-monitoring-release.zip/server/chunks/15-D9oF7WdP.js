const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BC7S39nm.js')).default;
const imports = ["_app/immutable/nodes/15.pljpVK0b.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/DHUAlugP.js","_app/immutable/chunks/CClvMc89.js","_app/immutable/chunks/niT0dDKO.js","_app/immutable/chunks/DaoVg8md.js","_app/immutable/chunks/Da_yRHvE.js","_app/immutable/chunks/Cn7nNa4a.js","_app/immutable/chunks/CFi_j4tm.js","_app/immutable/chunks/BtVlU6qO.js","_app/immutable/chunks/DhwrOBBZ.js","_app/immutable/chunks/C9BqufDr.js","_app/immutable/chunks/o2QMK_dP.js","_app/immutable/chunks/f0AS_gFo.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-D9oF7WdP.js.map
