const load = async ({ locals }) => {
  return {
    user: "budi"
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Dzzuhckd.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.D3eLInNG.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/BZDqfNkc.js","_app/immutable/chunks/o7DcF9Ny.js","_app/immutable/chunks/BemDnsh9.js","_app/immutable/chunks/BQkGgKpi.js","_app/immutable/chunks/S_BVD0_K.js","_app/immutable/chunks/DHUvJQCu.js","_app/immutable/chunks/Dk1FCHT_.js","_app/immutable/chunks/B59TdyIj.js","_app/immutable/chunks/BtbHRSZ0.js","_app/immutable/chunks/oDtILzwk.js","_app/immutable/chunks/Bg6RrkCw.js","_app/immutable/chunks/F3SxPL5n.js","_app/immutable/chunks/CYL8H4qi.js","_app/immutable/chunks/zZLIr5Lh.js","_app/immutable/chunks/CqgIQq5I.js","_app/immutable/chunks/CDFqimxN.js","_app/immutable/chunks/iv8aCNae.js","_app/immutable/chunks/KeILyCYU.js","_app/immutable/chunks/C1fdFZsT.js","_app/immutable/chunks/CftYWMCI.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-BhoOpyOl.js.map
