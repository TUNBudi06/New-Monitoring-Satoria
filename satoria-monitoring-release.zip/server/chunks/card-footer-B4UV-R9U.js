import { p as push, k as spread_attributes, l as clsx, v as bind_props, e as pop } from './index2-C_y23GpV.js';
import { c as cn } from './utils-zdf1KThM.js';

function Card_footer($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out += `<div${spread_attributes(
    {
      "data-slot": "card-footer",
      class: clsx(cn("flex items-center px-6 [.border-t]:pt-6", className)),
      ...restProps
    },
    null
  )}>`;
  children?.($$payload);
  $$payload.out += `<!----></div>`;
  bind_props($$props, { ref });
  pop();
}

export { Card_footer as C };
//# sourceMappingURL=card-footer-B4UV-R9U.js.map
