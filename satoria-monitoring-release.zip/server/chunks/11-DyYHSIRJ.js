const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BZTUT2Yf.js')).default;
const imports = ["_app/immutable/nodes/11.BpohP5Ez.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/A10nGaqm.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=11-DyYHSIRJ.js.map
