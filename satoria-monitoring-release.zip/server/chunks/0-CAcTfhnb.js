const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-0yB81X2U.js')).default;
const imports = ["_app/immutable/nodes/0.BIr3v7YL.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/DMzBSWS0.js"];
const stylesheets = ["_app/immutable/assets/0.D6gkSLPh.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-CAcTfhnb.js.map
