const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BZTUT2Yf.js')).default;
const imports = ["_app/immutable/nodes/11.B51OwGaY.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/Bup8ca7u.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=11-BvVJrLGK.js.map
