import { p as push, k as spread_attributes, l as clsx, u as bind_props, e as pop } from './index3-OytlP0AJ.js';
import { c as cn } from './utils-DnGaiUF2.js';

function Card_description($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out += `<p${spread_attributes(
    {
      "data-slot": "card-description",
      class: clsx(cn("text-muted-foreground text-sm", className)),
      ...restProps
    },
    null
  )}>`;
  children?.($$payload);
  $$payload.out += `<!----></p>`;
  bind_props($$props, { ref });
  pop();
}

export { Card_description as C };
//# sourceMappingURL=card-description-Cx_wKyom.js.map
