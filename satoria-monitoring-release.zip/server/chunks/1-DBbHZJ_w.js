const index = 1;
let component_cache;
const component = async () => component_cache ??= (await import('./error.svelte-CEWzyvZk.js')).default;
const imports = ["_app/immutable/nodes/1.umk1Pdw9.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/Cv85WRB7.js","_app/immutable/chunks/CNPJXPZ7.js","_app/immutable/chunks/CvhWP5Ll.js","_app/immutable/chunks/CeNUQTqR.js","_app/immutable/chunks/DDygTKsk.js","_app/immutable/chunks/DSQ_1cCE.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=1-DBbHZJ_w.js.map
