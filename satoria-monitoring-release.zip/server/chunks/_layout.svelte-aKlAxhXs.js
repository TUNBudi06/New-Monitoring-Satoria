import { A as Avatar, a as Avatar_image, b as Avatar_fallback, l as logo } from './logo2-B-ykGMhT.js';
import './index-DwrKR0Y-.js';
import './index2-DhlZV1j8.js';
import './utils-BS0-NKpy.js';
import './use-id-Da-kBeXU.js';
import './_commonjsHelpers-B85MJLTf.js';

function _layout($$payload, $$props) {
  let { children } = $$props;
  $$payload.out += `<div class="bg-muted flex min-h-svh flex-col items-center justify-center gap-6 p-6 md:p-10"><div class="flex w-full max-w-sm flex-col gap-6"><a href="/login" class="flex items-center gap-2 self-center font-medium"><div class="text-primary-foreground flex size-8 items-center justify-center rounded-md"><!---->`;
  Avatar($$payload, {
    class: "size-12",
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Avatar_image($$payload2, {
        src: logo,
        alt: "Logo",
        class: "h-10 w-10 rounded-md object-cover"
      });
      $$payload2.out += `<!----> <!---->`;
      Avatar_fallback($$payload2, {
        class: "bg-primary text-primary-foreground h-10 w-10 rounded-md",
        children: ($$payload3) => {
          $$payload3.out += `<!---->ST`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> PT. Satoria Aneka Pharma</a> `;
  children?.($$payload);
  $$payload.out += `<!----></div></div>`;
}

export { _layout as default };
//# sourceMappingURL=_layout.svelte-aKlAxhXs.js.map
