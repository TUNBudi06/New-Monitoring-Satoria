import { r as redirect } from './index-DHSpIlkf.js';
import { P as PRIVATE_JWT_SECRET, S as SESSION_REMEMBER, R as REFRESH_REMEMBER, J as JWT_ALGORITHM, C as COOKIE_MAX_AGE } from './private-a70Od6j7.js';
import { d as db, s as sessions, u as users } from './index4-Bq3YGG3j.js';
import { eq } from 'drizzle-orm';
import * as jwtm from 'jose';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'zod';

function sequence(...handlers) {
  const length = handlers.length;
  if (!length) return ({ event, resolve }) => resolve(event);
  return ({ event, resolve }) => {
    return apply_handle(0, event, {});
    function apply_handle(i, event2, parent_options) {
      const handle2 = handlers[i];
      return handle2({
        event: event2,
        resolve: (event3, options) => {
          const transformPageChunk = async ({ html, done }) => {
            if (options?.transformPageChunk) {
              html = await options.transformPageChunk({ html, done }) ?? "";
            }
            if (parent_options?.transformPageChunk) {
              html = await parent_options.transformPageChunk({ html, done }) ?? "";
            }
            return html;
          };
          const filterSerializedResponseHeaders = parent_options?.filterSerializedResponseHeaders ?? options?.filterSerializedResponseHeaders;
          const preload = parent_options?.preload ?? options?.preload;
          return i < length - 1 ? apply_handle(i + 1, event3, {
            transformPageChunk,
            filterSerializedResponseHeaders,
            preload
          }) : resolve(event3, { transformPageChunk, filterSerializedResponseHeaders, preload });
        }
      });
    }
  };
}
async function setIPSession(event, session) {
  const IP = event.getClientAddress();
  return await db.update(sessions).set({ net_address: IP }).where(eq(sessions.id, session.id)).returning().then((res) => res[0]);
}
async function updateActivitySession(sessionID) {
  const now = /* @__PURE__ */ new Date();
  return await db.update(sessions).set({ last_activity: now }).where(eq(sessions.id, sessionID)).returning().then((res) => res[0]);
}
async function handleSession(event, pld) {
  const payload = pld?.payload;
  if (!payload || !payload.token) {
    return { redirect: true };
  }
  const sessiondb = await db.select().from(sessions).where(eq(sessions.id, payload.token)).limit(1).then((res) => res[0]);
  if (!sessiondb) return { redirect: true };
  const now = /* @__PURE__ */ new Date();
  const expiredDate = sessiondb.expired ? new Date(sessiondb.expired) : null;
  if (expiredDate && expiredDate < now) return { redirect: true };
  const lastActivity = sessiondb.last_activity ? new Date(sessiondb.last_activity) : null;
  if (lastActivity && lastActivity < new Date(now.getTime() - SESSION_REMEMBER * 24 * 60 * 60 * 1e3)) {
    event.locals.alreadysigned = "session_logout";
    return { redirect: true };
  }
  await updateActivitySession(sessiondb.id);
  if (event.getClientAddress() !== sessiondb.net_address) {
    await setIPSession(event, sessiondb);
  }
  if (sessiondb.payload?._remember?.is) {
    const user = await db.select().from(users).where(eq(users.id, sessiondb.user_id)).limit(1).then((res) => res[0]);
    if (sessiondb.payload?._remember?._token !== user?.rememberMe) {
      return { redirect: true };
    }
  }
  if (sessiondb.payload?._token !== payload.id) {
    return { redirect: true };
  }
  const jwt_data = {
    id: sessiondb.payload?._token,
    token: sessiondb.id,
    user_id: sessiondb.user_id
  };
  const jwt = await new event.locals.jwt.sign(jwt_data).setExpirationTime(REFRESH_REMEMBER).setIssuedAt().setProtectedHeader({ alg: JWT_ALGORITHM, typ: "JWT" }).setIssuedAt().sign(Buffer.from(PRIVATE_JWT_SECRET, "base64"));
  event.cookies.set("refresh_token", jwt, {
    path: "/",
    httpOnly: false,
    secure: false,
    sameSite: "strict",
    maxAge: Number(COOKIE_MAX_AGE)
  });
  return { redirect: false };
}
const auth = async ({ event, resolve }) => {
  if (event.route.id?.startsWith("/(app)")) {
    const jwt = event.cookies.get("refresh_token");
    if (jwt) {
      try {
        const payload = await event.locals.jwt.verify(jwt, Buffer.from(PRIVATE_JWT_SECRET, "base64")).then((res) => res.payload);
        const sessiondb = await db.select().from(sessions).where(eq(sessions.id, payload.token)).limit(1).then((res) => res[0]);
        if (!sessiondb) {
          return redirect(301, "/login");
        }
        await setIPSession(event, sessiondb);
        if (payload?.id != sessiondb.payload?._token) {
          return redirect(301, "/login");
        }
        if (sessiondb.expired && new Date(sessiondb.expired) < /* @__PURE__ */ new Date()) {
          return redirect(301, "/login");
        }
      } catch (e) {
        const result = await handleSession(event, e);
        if (result.redirect) return redirect(301, "/login");
      }
    } else {
      return redirect(301, "/login");
    }
  }
  return resolve(event);
};
const login = async ({ event, resolve }) => {
  if (event.url.pathname?.startsWith("/login")) {
    const jwt = event.cookies.get("refresh_token");
    if (jwt) {
      try {
        const payload = await event.locals.jwt.verify(jwt, Buffer.from(PRIVATE_JWT_SECRET, "base64")).then((res) => res.payload);
        const sessiondb = await db.select().from(sessions).where(eq(sessions.id, payload.token)).limit(1).then((res) => res[0]);
        if (sessiondb) {
          if (sessiondb.expired && new Date(sessiondb.expired) < /* @__PURE__ */ new Date()) {
            event.locals.alreadysigned = "session_logout";
            return redirect(301, "/login");
          }
          if (sessiondb.payload?._token !== payload.id) {
            event.locals.alreadysigned = "session_logout";
            return redirect(301, "/login");
          }
          await setIPSession(event, sessiondb);
          event.locals.alreadysigned = "login";
        }
      } catch (e) {
        const result = await handleSession(event, e);
        if (!result.redirect) event.locals.alreadysigned = "login";
      }
    }
  }
  return resolve(event);
};
const authincator = sequence(auth, login);
const tools = async ({ event, resolve }) => {
  event.locals.jwt = {
    sign: jwtm.SignJWT,
    unsecuredJwt: jwtm.UnsecuredJWT,
    verify: jwtm.jwtVerify,
    decode: jwtm.decodeJwt
  };
  return resolve(event);
};
const devtool = async ({ event, resolve }) => {
  if (event.url.pathname.startsWith("/.well-known/appspecific/com.chrome.devtools")) {
    return new Response(null, { status: 204 });
  }
  return resolve(event);
};
const testingOnly = async ({ event, resolve }) => {
  return resolve(event);
};
const handle = sequence(tools, devtool, authincator, testingOnly);

export { devtool, handle };
//# sourceMappingURL=hooks.server-C2-q0Os0.js.map
