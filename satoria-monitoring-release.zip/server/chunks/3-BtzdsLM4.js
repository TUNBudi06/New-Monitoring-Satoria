const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-D2qVUJSV.js')).default;
const imports = ["_app/immutable/nodes/3.z70THzDD.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/BZDqfNkc.js","_app/immutable/chunks/o7DcF9Ny.js","_app/immutable/chunks/BemDnsh9.js","_app/immutable/chunks/BQkGgKpi.js","_app/immutable/chunks/CftYWMCI.js","_app/immutable/chunks/DHUvJQCu.js","_app/immutable/chunks/B59TdyIj.js","_app/immutable/chunks/oDtILzwk.js","_app/immutable/chunks/Bg6RrkCw.js","_app/immutable/chunks/F3SxPL5n.js","_app/immutable/chunks/DQfRr7yB.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-BtzdsLM4.js.map
