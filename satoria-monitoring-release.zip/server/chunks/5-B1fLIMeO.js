import './client-BIHfTmYE.js';
import { s as superValidate, z as zod, a as setError, m as message } from './zod-DxRxAYAl.js';
import { f as fail } from './index2-DHSpIlkf.js';
import { z } from 'zod';
import { d as db, u as users } from './index-C6qlw1oi.js';
import deviceDetector from 'node-device-detector';
import { eq } from 'drizzle-orm';
import bcrypt__default__default from 'bcrypt';
import './exports-B9zQMW2T.js';
import './index3-OytlP0AJ.js';
import './index-server2-4V4BZ4ml.js';
import './stringify-nj1_0ECd.js';
import './_commonjsHelpers-B85MJLTf.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';

const userSchemaName = z.object({
  firstname: z.string().min(1).max(100),
  lastname: z.string().min(1).max(100)
});
const userSchemaCredential = z.object({
  email: z.string().email(),
  username: z.string().min(1).max(100)
});
const userSchemaPassword = z.object({
  old_password: z.string().min(6, "Old Password must be at least 6 characters"),
  new_Password: z.string().min(6, "New Password must be at least 6 characters"),
  new_confirmPassword: z.string().min(6, "Confirm Password must be at least 6 characters")
});

function userPromise(event) {
  const { cookies, locals } = event;
  return new Promise((resolve, reject) => {
    const jwt = locals.jwt.decode(cookies.get("refresh_token") || "");
    if (jwt) {
      resolve(jwt);
    } else {
      reject("cant be found");
    }
  }).then((jwt_string) => {
    return db.select().from(users).where(eq(users.id, jwt_string.user_id)).then((res) => res[0]);
  });
}
const load = async (event) => {
  const user = await userPromise(event);
  const [names, password, credential, device] = await Promise.all([
    superValidate(user, zod(userSchemaName)),
    superValidate(zod(userSchemaPassword)),
    superValidate(user, zod(userSchemaCredential)),
    new deviceDetector().detect(event.request.headers.get("user-agent") || "")
  ]);
  return {
    names,
    password,
    credential,
    device
  };
};
const actions = {
  UpdateName: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaName));
    const user = await userPromise(event);
    if (!form.valid) {
      const [password, credential, device] = await Promise.all([
        superValidate(zod(userSchemaPassword)),
        superValidate(user, zod(userSchemaCredential)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names: form,
        password,
        credential,
        device
      });
    }
    await db.update(users).set({
      firstname: form.data.firstname,
      lastname: form.data.lastname
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your name");
  },
  UpdateCredential: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaCredential));
    const user = await userPromise(event);
    if (!form.valid) {
      const [names, password, device] = await Promise.all([
        superValidate(user, zod(userSchemaName)),
        superValidate(zod(userSchemaPassword)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names,
        password,
        credential: form,
        device
      });
    }
    await db.update(users).set({
      email: form.data.email,
      username: form.data.username
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your credentials");
  },
  UpdatePassword: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaPassword));
    const user = await userPromise(event);
    if (!form.valid) {
      const [names, credential, device] = await Promise.all([
        superValidate(user, zod(userSchemaName)),
        superValidate(user, zod(userSchemaCredential)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names,
        credential,
        password: form,
        device
      });
    }
    if (form.data.new_Password !== form.data.new_confirmPassword) {
      return setError(
        form,
        "new_confirmPassword",
        "New Password and Confirm Password do not match"
      );
    }
    if (!await bcrypt__default__default.compare(form.data.old_password, user.password)) {
      return setError(form, "old_password", "Old Password is incorrect");
    }
    const password = await bcrypt__default__default.hash(form.data.new_Password, 12);
    await db.update(users).set({
      password
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your password");
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CrZz10Tk.js')).default;
const server_id = "src/routes/(app)/account/+page.server.ts";
const imports = ["_app/immutable/nodes/5.JL1KQ1HH.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/Ck2fqhG2.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/D1GQsrue.js","_app/immutable/chunks/CrQ87Cea.js","_app/immutable/chunks/Y9se7Tnw.js","_app/immutable/chunks/C5SJzsNr.js","_app/immutable/chunks/Bghoqm9w.js","_app/immutable/chunks/ByJP-KLq.js","_app/immutable/chunks/BisprqW_.js","_app/immutable/chunks/J4MOcOLg.js","_app/immutable/chunks/DgZxKvym.js","_app/immutable/chunks/CL19QPeb.js","_app/immutable/chunks/COfIiwau.js","_app/immutable/chunks/BgmoFf8y.js","_app/immutable/chunks/mYIg1c-4.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/PEZGSbjs.js","_app/immutable/chunks/CaCqigIK.js","_app/immutable/chunks/D0WhWLe0.js","_app/immutable/chunks/B2XLuyqE.js"];
const stylesheets = ["_app/immutable/assets/Toaster.D7TgzYVC.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=5-B1fLIMeO.js.map
