const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CLJhqDmT.js')).default;
const imports = ["_app/immutable/nodes/15.CWiCZjKL.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/B3uzrfl-.js","_app/immutable/chunks/DjVnfXhZ.js","_app/immutable/chunks/OKggTVyC.js","_app/immutable/chunks/CJfCnddR.js","_app/immutable/chunks/B3ZxWL9O.js","_app/immutable/chunks/CSrnH8IZ.js","_app/immutable/chunks/BSnVJNDa.js","_app/immutable/chunks/4fFwGPg6.js","_app/immutable/chunks/9lx5pHay.js","_app/immutable/chunks/DtLvkNEx.js","_app/immutable/chunks/SPtOUWa1.js","_app/immutable/chunks/BZF4576O.js","_app/immutable/chunks/BOk-cWR7.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-B_m__qiq.js.map
