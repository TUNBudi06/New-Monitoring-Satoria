const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-uFc04tD8.js')).default;
const imports = ["_app/immutable/nodes/11.CIV-fHBG.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/83YYTNZR.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=11-BNU6yoyT.js.map
