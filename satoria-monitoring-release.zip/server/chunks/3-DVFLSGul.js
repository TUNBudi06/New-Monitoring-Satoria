const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-DZ1waKTm.js')).default;
const imports = ["_app/immutable/nodes/3.BX1wTu4y.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/Y9se7Tnw.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/D1GQsrue.js","_app/immutable/chunks/Hu11wkTB.js","_app/immutable/chunks/Bghoqm9w.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/COfIiwau.js","_app/immutable/chunks/BisprqW_.js","_app/immutable/chunks/xCbqk_GY.js","_app/immutable/chunks/D3Q3_Xcg.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-DVFLSGul.js.map
