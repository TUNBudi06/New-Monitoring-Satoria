import { p as push, w as copy_payload, x as assign_payload, e as pop, D as await_block, j as ensure_array_like } from './index2-C_y23GpV.js';
import { C as Card, a as Card_header, b as Card_content } from './card-header-BRYX2G23.js';
import { C as Card_description } from './card-description-DczOAeNm.js';
import { C as Card_title } from './card-title-BhIXASx0.js';
import { g as getCoreRowModel } from './render-helpers-BoMdKG-p.js';
import { c as createSvelteTable, T as Table, a as Table_header, b as Table_body, d as Table_row, e as Table_head, f as Table_cell, F as Flex_render } from './table-row-Dhmn4JXs.js';
import { B as Button } from './button-D_a_uBj6.js';
import { s as setDevicesAdminStore, a as setUserIdContext, C as ColumnsFormat } from './6-EZOWDa6v.js';
import './client-Chw5mV5o.js';
import './memoize-4dA32NW1.js';
import './index-DHSpIlkf.js';
import 'zod';
import './utils-zdf1KThM.js';
import './index4-CQhZZcHY.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-DXaAhYwL.js';
import 'drizzle-orm';
import 'crypto';
import 'bcrypt';
import './exports-DJ-e4XgW.js';
import './index-server-DpxecShX.js';
import './app-8Apsod8E.js';
import './_commonjsHelpers-B85MJLTf.js';

function Data_Table($$payload, $$props) {
  push();
  let { data, columns } = $$props;
  const table = createSvelteTable({
    get data() {
      return data;
    },
    columns,
    getCoreRowModel: getCoreRowModel()
  });
  $$payload.out += `<div class="rounded-md border"><!---->`;
  Table($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Table_header($$payload2, {
        children: ($$payload3) => {
          const each_array = ensure_array_like(table.getHeaderGroups());
          $$payload3.out += `<!--[-->`;
          for (let $$index_1 = 0, $$length = each_array.length; $$index_1 < $$length; $$index_1++) {
            let headerGroup = each_array[$$index_1];
            $$payload3.out += `<!---->`;
            Table_row($$payload3, {
              children: ($$payload4) => {
                const each_array_1 = ensure_array_like(headerGroup.headers);
                $$payload4.out += `<!--[-->`;
                for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
                  let header = each_array_1[$$index];
                  $$payload4.out += `<!---->`;
                  Table_head($$payload4, {
                    children: ($$payload5) => {
                      if (!header.isPlaceholder) {
                        $$payload5.out += "<!--[-->";
                        Flex_render($$payload5, {
                          content: header.column.columnDef.header,
                          context: header.getContext()
                        });
                      } else {
                        $$payload5.out += "<!--[!-->";
                      }
                      $$payload5.out += `<!--]-->`;
                    },
                    $$slots: { default: true }
                  });
                  $$payload4.out += `<!---->`;
                }
                $$payload4.out += `<!--]-->`;
              },
              $$slots: { default: true }
            });
            $$payload3.out += `<!---->`;
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <!---->`;
      Table_body($$payload2, {
        children: ($$payload3) => {
          const each_array_2 = ensure_array_like(table.getRowModel().rows);
          if (each_array_2.length !== 0) {
            $$payload3.out += "<!--[-->";
            for (let $$index_3 = 0, $$length = each_array_2.length; $$index_3 < $$length; $$index_3++) {
              let row = each_array_2[$$index_3];
              $$payload3.out += `<!---->`;
              Table_row($$payload3, {
                "data-state": row.getIsSelected() && "selected",
                children: ($$payload4) => {
                  const each_array_3 = ensure_array_like(row.getVisibleCells());
                  $$payload4.out += `<!--[-->`;
                  for (let $$index_2 = 0, $$length2 = each_array_3.length; $$index_2 < $$length2; $$index_2++) {
                    let cell = each_array_3[$$index_2];
                    $$payload4.out += `<!---->`;
                    Table_cell($$payload4, {
                      children: ($$payload5) => {
                        Flex_render($$payload5, {
                          content: cell.column.columnDef.cell,
                          context: cell.getContext()
                        });
                      },
                      $$slots: { default: true }
                    });
                    $$payload4.out += `<!---->`;
                  }
                  $$payload4.out += `<!--]-->`;
                },
                $$slots: { default: true }
              });
              $$payload3.out += `<!---->`;
            }
          } else {
            $$payload3.out += "<!--[!-->";
            $$payload3.out += `<!---->`;
            Table_row($$payload3, {
              children: ($$payload4) => {
                $$payload4.out += `<!---->`;
                Table_cell($$payload4, {
                  colspan: columns.length,
                  class: "h-24 text-center",
                  children: ($$payload5) => {
                    $$payload5.out += `<!---->No results.`;
                  },
                  $$slots: { default: true }
                });
                $$payload4.out += `<!---->`;
              },
              $$slots: { default: true }
            });
            $$payload3.out += `<!---->`;
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div>`;
  pop();
}
function _page($$payload, $$props) {
  push();
  let dialogOpen = false;
  let dialog = {
    cc: false,
    cp: false,
    dl: false,
    udl: false,
    data: {
      id: 0,
      username: "admin",
      email: "admin@admin.com"
    }
  };
  let { data } = $$props;
  setDevicesAdminStore(dialog);
  setUserIdContext(Number(data.userJWT?.user_id));
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> <!---->`;
    Card($$payload2, {
      class: "h-full max-h-svh w-full",
      children: ($$payload3) => {
        $$payload3.out += `<!---->`;
        Card_header($$payload3, {
          children: ($$payload4) => {
            $$payload4.out += `<!---->`;
            Card_title($$payload4, {
              class: "text-2xl font-bold",
              children: ($$payload5) => {
                $$payload5.out += `<!---->Admin Dashboard`;
              },
              $$slots: { default: true }
            });
            $$payload4.out += `<!----> <!---->`;
            Card_description($$payload4, {
              class: "text-muted-foreground",
              children: ($$payload5) => {
                $$payload5.out += `<!---->Manage all account settings and preferences.`;
              },
              $$slots: { default: true }
            });
            $$payload4.out += `<!---->`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!----> <!---->`;
        Card_content($$payload3, {
          class: "space-y-4",
          children: ($$payload4) => {
            Button($$payload4, {
              variant: "outline",
              class: "w-full bg-blue-400 hover:bg-blue-300",
              onclick: () => dialogOpen = !dialogOpen,
              children: ($$payload5) => {
                $$payload5.out += `<!---->Add Account+`;
              },
              $$slots: { default: true }
            });
            $$payload4.out += `<!----> <!---->`;
            Card($$payload4, {
              children: ($$payload5) => {
                $$payload5.out += `<!---->`;
                Card_header($$payload5, {
                  children: ($$payload6) => {
                    $$payload6.out += `<!---->`;
                    Card_title($$payload6, {
                      class: "text-lg font-semibold",
                      children: ($$payload7) => {
                        $$payload7.out += `<!---->User Accounts`;
                      },
                      $$slots: { default: true }
                    });
                    $$payload6.out += `<!---->`;
                  },
                  $$slots: { default: true }
                });
                $$payload5.out += `<!----> <!---->`;
                Card_content($$payload5, {
                  children: ($$payload6) => {
                    await_block($$payload6, data.users, () => {
                    }, (users) => {
                      Data_Table($$payload6, { columns: ColumnsFormat, data: users });
                    });
                    $$payload6.out += `<!--]-->`;
                  },
                  $$slots: { default: true }
                });
                $$payload5.out += `<!---->`;
              },
              $$slots: { default: true }
            });
            $$payload4.out += `<!---->`;
          },
          $$slots: { default: true }
        });
        $$payload3.out += `<!---->`;
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!---->`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-n3ZtnoBN.js.map
