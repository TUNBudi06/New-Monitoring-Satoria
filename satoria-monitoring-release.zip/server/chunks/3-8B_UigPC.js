const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-aKlAxhXs.js')).default;
const imports = ["_app/immutable/nodes/3.VLEW9TlJ.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/ByuCpQji.js","_app/immutable/chunks/0s6GNCna.js","_app/immutable/chunks/tUpKhWA1.js","_app/immutable/chunks/Bl_P7zlk.js","_app/immutable/chunks/apuB4Uj0.js","_app/immutable/chunks/BD0PCi7w.js","_app/immutable/chunks/BDXrhozL.js","_app/immutable/chunks/h9yqfu6I.js","_app/immutable/chunks/gK-5M4dR.js","_app/immutable/chunks/DQfRr7yB.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-8B_UigPC.js.map
