import { p as push, e as pop } from './index2-C_y23GpV.js';
import { C as Card, a as Card_header, b as Card_content } from './card-header-BRYX2G23.js';
import { C as Card_title } from './card-title-BhIXASx0.js';
import './alert-DH-1ku1H.js';
import 'echarts';
import './client-Chw5mV5o.js';
import './memoize-4dA32NW1.js';
import './index-DHSpIlkf.js';
import './12-C_1QLpUN.js';
import './button-D_a_uBj6.js';
import './utils-zdf1KThM.js';
import './exports-DJ-e4XgW.js';
import './index-server-DpxecShX.js';
import './app-8Apsod8E.js';
import './_commonjsHelpers-B85MJLTf.js';
import 'zod';
import './zod4-DuqeCOVW.js';
import 'zod/v4/core';
import 'zod/v4';
import './index4-CQhZZcHY.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-DXaAhYwL.js';
import 'drizzle-orm';

function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  $$payload.out += `<div class="space-y-4"><!---->`;
  Card($$payload, {
    class: "w-full",
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Card_header($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card_title($$payload3, {
            class: "w-full text-center text-2xl font-bold",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Configuration Line 2 Autoclave A`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <!---->`;
      Card_content($$payload2, {
        children: ($$payload3) => {
          {
            $$payload3.out += "<!--[!-->";
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-BPxQlDe_.js.map
