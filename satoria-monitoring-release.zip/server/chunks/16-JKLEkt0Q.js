const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Cq--MB9B.js')).default;
const imports = ["_app/immutable/nodes/16.D1yzLHlw.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B41hdK34.js","_app/immutable/chunks/CCAte5Uw.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=16-JKLEkt0Q.js.map
