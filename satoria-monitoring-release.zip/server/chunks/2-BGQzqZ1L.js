import { d as db, u as users } from './index4-D0Nb1HJJ.js';
import { eq } from 'drizzle-orm';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';

const load = async (event) => {
  const jwt_cookie = event.cookies.get("refresh_token");
  let user;
  try {
    const payload = event.locals.jwt.decode(jwt_cookie);
    user = await db.select({
      username: users.username,
      email: users.email,
      firstname: users.firstname,
      lastname: users.lastname,
      type: users.role
    }).from(users).where(eq(users.id, payload.user_id)).limit(1).then((res) => res[0]);
  } catch (e) {
    console.error("JWT decode error:", e);
  }
  return {
    user: user || null
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-D9ny2u05.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.Bhv8tO6W.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/B3qc7meF.js","_app/immutable/chunks/CsX36sAN.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/DzYA0N7_.js","_app/immutable/chunks/CxJc_Azy.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/Dk72urO7.js","_app/immutable/chunks/N2eanvh1.js","_app/immutable/chunks/Cg1X0_6c.js","_app/immutable/chunks/DxvS11ZK.js","_app/immutable/chunks/DUTBo3uO.js","_app/immutable/chunks/ZK-3N7xi.js","_app/immutable/chunks/Dnf__lyf.js","_app/immutable/chunks/CiXAj25e.js","_app/immutable/chunks/D1AqOXBH.js","_app/immutable/chunks/zUc9I7b_.js","_app/immutable/chunks/hOen_43f.js","_app/immutable/chunks/CxhU8tJ3.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-BGQzqZ1L.js.map
