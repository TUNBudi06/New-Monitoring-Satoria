import './client-BIHfTmYE.js';
import { s as superValidate, z as zod, a as setError, m as message } from './zod-DxRxAYAl.js';
import { f as fail } from './index2-DHSpIlkf.js';
import { z } from 'zod';
import { d as db, u as users, s as sessions } from './index-C6qlw1oi.js';
import { and, eq, isNull } from 'drizzle-orm';
import * as bcrypt__default from 'bcrypt';
import * as crypto from 'crypto';
import { R as REFRESH_REMEMBER, J as JWT_ALGORITHM, P as PRIVATE_JWT_SECRET, C as COOKIE_MAX_AGE } from './private-a70Od6j7.js';

const emailSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters long"),
  checked: z.boolean(),
  type: z.enum(["email", "username"]).default("email")
});
const usernameSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters long"),
  password: z.string().min(6, "Password must be at least 6 characters long"),
  checked: z.boolean(),
  type: z.enum(["email", "username"]).default("username")
});

const DateNow = /* @__PURE__ */ new Date();
const load = async (event) => {
  return {
    email: await superValidate(zod(emailSchema)),
    username: await superValidate(zod(usernameSchema)),
    success: false,
    isSigned: event.locals.alreadysigned
  };
};
async function loginEmail(event) {
  const form = await superValidate(event, zod(emailSchema));
  if (!form.valid) {
    return fail(400, {
      email: form,
      username: await superValidate(zod(usernameSchema))
    });
  }
  const user = await db.select().from(users).where(and(eq(users.email, form.data.email), isNull(users.deletedAt))).limit(1);
  if (user.length === 0) {
    return setError(form, "email", "User doesnt exists.", { status: 404 });
  }
  const ret = await loginCookies(event, user[0], form);
  return ret || { email: form, username: await superValidate(zod(usernameSchema)) };
}
async function loginUsername(event) {
  const form = await superValidate(event, zod(usernameSchema));
  if (!form.valid) {
    return fail(400, {
      username: form,
      email: await superValidate(zod(emailSchema))
    });
  }
  const user = await db.select().from(users).where(and(eq(users.username, form.data.username), isNull(users.deletedAt))).limit(1);
  if (user.length === 0) {
    return setError(form, "username", "User doesnt exists.", { status: 404 });
  }
  const ret = await loginCookies(event, user[0], form);
  return ret || { username: form, email: await superValidate(zod(emailSchema)) };
}
async function sessionDBHandle(event, user, session) {
  let sessiondb;
  const find_session_by_ip = await db.select().from(sessions).where(eq(sessions.net_address, event.getClientAddress())).limit(1).then((res) => res[0]);
  if (find_session_by_ip) {
    await db.update(sessions).set(session).where(eq(sessions.id, find_session_by_ip.id));
    sessiondb = await db.select().from(sessions).where(eq(sessions.id, find_session_by_ip.id)).limit(1).then((res) => res[0]);
  } else {
    session.id = crypto.randomBytes(16).toString("hex");
    sessiondb = await db.insert(sessions).values(session).returning().then((res) => res[0]);
  }
  return sessiondb;
}
async function loginCookies(event, user, form) {
  if (!await bcrypt__default.compare(form?.data.password, user.password)) {
    return setError(form, "password", "Invalid password", { status: 401 });
  }
  const session_data = {
    user_id: user.id,
    net_address: event.getClientAddress(),
    user_agent: event.request.headers.get("user-agent") || null,
    payload: {
      _token: crypto.randomBytes(32).toString("hex"),
      _remember: {
        is: form?.data.checked,
        _token: user.rememberMe
      }
    },
    last_activity: /* @__PURE__ */ new Date(),
    createdAt: /* @__PURE__ */ new Date()
  };
  if (!form?.data.checked) {
    session_data.expired = new Date(DateNow.getTime() + 24 * 60 * 60 * 1e3);
  } else {
    session_data.expired = null;
  }
  const session_resultDB = await sessionDBHandle(
    event,
    user,
    session_data
  );
  const jwt_data = {
    id: session_resultDB?.payload?._token,
    token: session_resultDB?.id,
    user_id: user.id
  };
  const jwt = await new event.locals.jwt.sign(jwt_data).setExpirationTime(REFRESH_REMEMBER).setIssuedAt().setProtectedHeader({ alg: JWT_ALGORITHM, typ: "JWT" }).setIssuedAt().sign(Buffer.from(PRIVATE_JWT_SECRET, "base64"));
  event.cookies.set("refresh_token", jwt, {
    path: "/",
    httpOnly: false,
    secure: false,
    sameSite: "strict",
    maxAge: Number(COOKIE_MAX_AGE)
  });
  return message(form, "Login successful");
}
const actions = {
  email: loginEmail,
  username: loginUsername
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 17;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-g_3Tr7Wq.js')).default;
const server_id = "src/routes/(login)/login/+page.server.ts";
const imports = ["_app/immutable/nodes/17.BwNT71c7.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/D1GQsrue.js","_app/immutable/chunks/J4MOcOLg.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/DgZxKvym.js","_app/immutable/chunks/BisprqW_.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/Bghoqm9w.js","_app/immutable/chunks/Y9se7Tnw.js","_app/immutable/chunks/CL19QPeb.js","_app/immutable/chunks/C5SJzsNr.js","_app/immutable/chunks/COfIiwau.js","_app/immutable/chunks/Ck2fqhG2.js","_app/immutable/chunks/BgmoFf8y.js","_app/immutable/chunks/mYIg1c-4.js","_app/immutable/chunks/Bpa_vOvn.js","_app/immutable/chunks/Nzqr8m1V.js","_app/immutable/chunks/xCbqk_GY.js","_app/immutable/chunks/CrQ87Cea.js","_app/immutable/chunks/ByJP-KLq.js","_app/immutable/chunks/CaCqigIK.js","_app/immutable/chunks/PEZGSbjs.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/BvWSGiVL.js","_app/immutable/chunks/B2XLuyqE.js","_app/immutable/chunks/D0WhWLe0.js"];
const stylesheets = ["_app/immutable/assets/Toaster.D7TgzYVC.css"];
const fonts = [];

var _17 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  server: _page_server_ts,
  server_id: server_id,
  stylesheets: stylesheets
});

export { _17 as _, emailSchema as e, usernameSchema as u };
//# sourceMappingURL=17-CAzfHN7t.js.map
