import * as jwtm from 'jose';

function sequence(...handlers) {
  const length = handlers.length;
  if (!length) return ({ event, resolve }) => resolve(event);
  return ({ event, resolve }) => {
    return apply_handle(0, event, {});
    function apply_handle(i, event2, parent_options) {
      const handle2 = handlers[i];
      return handle2({
        event: event2,
        resolve: (event3, options) => {
          const transformPageChunk = async ({ html, done }) => {
            if (options?.transformPageChunk) {
              html = await options.transformPageChunk({ html, done }) ?? "";
            }
            if (parent_options?.transformPageChunk) {
              html = await parent_options.transformPageChunk({ html, done }) ?? "";
            }
            return html;
          };
          const filterSerializedResponseHeaders = parent_options?.filterSerializedResponseHeaders ?? options?.filterSerializedResponseHeaders;
          const preload = parent_options?.preload ?? options?.preload;
          return i < length - 1 ? apply_handle(i + 1, event3, {
            transformPageChunk,
            filterSerializedResponseHeaders,
            preload
          }) : resolve(event3, { transformPageChunk, filterSerializedResponseHeaders, preload });
        }
      });
    }
  };
}
const jwt = async ({ event, resolve }) => {
  event.locals.jwt = {
    sign: jwtm.SignJWT,
    unsecuredJwt: jwtm.UnsecuredJWT,
    verify: jwtm.jwtVerify,
    decode: jwtm.decodeJwt
  };
  return resolve(event);
};
const devtool = async ({ event, resolve }) => {
  if (event.url.pathname.startsWith("/.well-known/appspecific/com.chrome.devtools")) {
    return new Response(null, { status: 204 });
  }
  return resolve(event);
};
const testingOnly = async ({ event, resolve }) => {
  return resolve(event);
};
const handle = sequence(jwt, devtool, testingOnly);

export { devtool, handle };
//# sourceMappingURL=hooks.server-Cjes-Fmo.js.map
