import './client-BYfstKI-.js';
import { s as superValidate, z as zod, a as setError, m as message } from './zod-B9fgBnn4.js';
import { f as fail } from './index-DHSpIlkf.js';
import { z } from 'zod';
import { d as db, u as users } from './index4-Bq3YGG3j.js';
import deviceDetector from 'node-device-detector';
import { eq } from 'drizzle-orm';
import bcrypt__default__default from 'bcrypt';
import './index2-OytlP0AJ.js';
import './exports-Ch6SmBKb.js';
import './index-server2-X77dWp9g.js';
import './stringify-nj1_0ECd.js';
import './_commonjsHelpers-B85MJLTf.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';

const userSchemaName = z.object({
  firstname: z.string().min(1).max(100),
  lastname: z.string().min(1).max(100)
});
const userSchemaCredential = z.object({
  email: z.string().email(),
  username: z.string().min(1).max(100)
});
const userSchemaPassword = z.object({
  old_password: z.string().min(6, "Old Password must be at least 6 characters"),
  new_Password: z.string().min(6, "New Password must be at least 6 characters"),
  new_confirmPassword: z.string().min(6, "Confirm Password must be at least 6 characters")
});

function userPromise(event) {
  const { cookies, locals } = event;
  return new Promise((resolve, reject) => {
    const jwt = locals.jwt.decode(cookies.get("refresh_token") || "");
    if (jwt) {
      resolve(jwt);
    } else {
      reject("cant be found");
    }
  }).then((jwt_string) => {
    return db.select().from(users).where(eq(users.id, jwt_string.user_id)).then((res) => res[0]);
  });
}
const load = async (event) => {
  const user = await userPromise(event);
  const [names, password, credential, device] = await Promise.all([
    superValidate(user, zod(userSchemaName)),
    superValidate(zod(userSchemaPassword)),
    superValidate(user, zod(userSchemaCredential)),
    new deviceDetector().detect(event.request.headers.get("user-agent") || "")
  ]);
  return {
    names,
    password,
    credential,
    device
  };
};
const actions = {
  UpdateName: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaName));
    const user = await userPromise(event);
    if (!form.valid) {
      const [password, credential, device] = await Promise.all([
        superValidate(zod(userSchemaPassword)),
        superValidate(user, zod(userSchemaCredential)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names: form,
        password,
        credential,
        device
      });
    }
    await db.update(users).set({
      firstname: form.data.firstname,
      lastname: form.data.lastname
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your name");
  },
  UpdateCredential: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaCredential));
    const user = await userPromise(event);
    if (!form.valid) {
      const [names, password, device] = await Promise.all([
        superValidate(user, zod(userSchemaName)),
        superValidate(zod(userSchemaPassword)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names,
        password,
        credential: form,
        device
      });
    }
    await db.update(users).set({
      email: form.data.email,
      username: form.data.username
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your credentials");
  },
  UpdatePassword: async (event) => {
    const { request } = event;
    const form = await superValidate(request, zod(userSchemaPassword));
    const user = await userPromise(event);
    if (!form.valid) {
      const [names, credential, device] = await Promise.all([
        superValidate(user, zod(userSchemaName)),
        superValidate(user, zod(userSchemaCredential)),
        new deviceDetector().detect(event.request.headers.get("user-agent") || "")
      ]);
      return fail(400, {
        names,
        credential,
        password: form,
        device
      });
    }
    if (form.data.new_Password !== form.data.new_confirmPassword) {
      return setError(
        form,
        "new_confirmPassword",
        "New Password and Confirm Password do not match"
      );
    }
    if (!await bcrypt__default__default.compare(form.data.old_password, user.password)) {
      return setError(form, "old_password", "Old Password is incorrect");
    }
    const password = await bcrypt__default__default.hash(form.data.new_Password, 12);
    await db.update(users).set({
      password
    }).where(eq(users.id, user.id)).returning().then((res) => res[0]);
    return message(form, "Successfully updated your password");
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 5;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DoxOKxkQ.js')).default;
const server_id = "src/routes/(app)/account/+page.server.ts";
const imports = ["_app/immutable/nodes/5.ZOsfJRTf.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/YFp1XVmH.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/B5_kf4jH.js","_app/immutable/chunks/CCAte5Uw.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js","_app/immutable/chunks/Cocm3y04.js","_app/immutable/chunks/DPibCUq0.js","_app/immutable/chunks/BdokIwwV.js","_app/immutable/chunks/jOYcctrt.js","_app/immutable/chunks/DkjyHJ0x.js","_app/immutable/chunks/BVFBc1gU.js","_app/immutable/chunks/MIwj1XX2.js","_app/immutable/chunks/BdMBCV5W.js","_app/immutable/chunks/BDwlTwo-.js","_app/immutable/chunks/B41hdK34.js","_app/immutable/chunks/Bc0mjKXN.js","_app/immutable/chunks/YdHuoDl9.js","_app/immutable/chunks/Doo5YQIh.js","_app/immutable/chunks/CNDr1Z7s.js"];
const stylesheets = ["_app/immutable/assets/Toaster.D7TgzYVC.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=5-DlY5P2_5.js.map
