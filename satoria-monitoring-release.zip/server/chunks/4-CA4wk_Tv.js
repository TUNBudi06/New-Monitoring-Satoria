const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BMvKVNpM.js')).default;
const imports = ["_app/immutable/nodes/4.Bk-yu6A3.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/Cv85WRB7.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=4-CA4wk_Tv.js.map
