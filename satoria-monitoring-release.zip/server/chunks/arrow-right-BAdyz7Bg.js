import { p as push, f as spread_props, e as pop } from './index3-OytlP0AJ.js';
import { I as Icon } from './Icon-xU8aaf28.js';

function Arrow_right($$payload, $$props) {
  push();
  let { $$slots, $$events, ...props } = $$props;
  const iconNode = [
    ["path", { "d": "M5 12h14" }],
    ["path", { "d": "m12 5 7 7-7 7" }]
  ];
  Icon($$payload, spread_props([
    { name: "arrow-right" },
    props,
    {
      iconNode,
      children: ($$payload2) => {
        props.children?.($$payload2);
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
  pop();
}

export { Arrow_right as A };
//# sourceMappingURL=arrow-right-BAdyz7Bg.js.map
