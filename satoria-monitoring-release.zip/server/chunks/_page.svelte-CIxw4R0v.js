import { p as push, w as copy_payload, x as assign_payload, e as pop, k as spread_attributes, l as clsx, v as bind_props } from './index2-C_y23GpV.js';
import { C as Card, a as Card_header, b as Card_content } from './card-header-BRYX2G23.js';
import { C as Card_footer } from './card-footer-B4UV-R9U.js';
import './button-D_a_uBj6.js';
import { e as emailSchema, u as usernameSchema } from './18-jV9C0pAh.js';
import './client-Chw5mV5o.js';
import { b as superForm, c as zodClient } from './zod-CwoAiKG0.js';
import './index-DHSpIlkf.js';
import { c as cn } from './utils-zdf1KThM.js';
import 'zod';
import './index4-D0Nb1HJJ.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';
import 'drizzle-orm';
import 'bcrypt';
import 'crypto';
import './exports-DJ-e4XgW.js';
import './index-server-DpxecShX.js';
import './app-8Apsod8E.js';
import './_commonjsHelpers-B85MJLTf.js';

function Skeleton($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out += `<div${spread_attributes(
    {
      "data-slot": "skeleton",
      class: clsx(cn("bg-accent animate-pulse rounded-md", className)),
      ...restProps
    },
    null
  )}></div>`;
  bind_props($$props, { ref });
  pop();
}
function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  superForm(data.email, { validators: zodClient(emailSchema) });
  superForm(data.username, { validators: zodClient(usernameSchema) });
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="flex flex-col gap-6">`;
    {
      $$payload2.out += "<!--[!-->";
      $$payload2.out += `<!---->`;
      Card($$payload2, {
        class: "space-y-4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card_header($$payload3, {
            children: ($$payload4) => {
              Skeleton($$payload4, { class: "h-6 w-32" });
              $$payload4.out += `<!----> `;
              Skeleton($$payload4, { class: "h-4 w-full max-w-[200px]" });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <!---->`;
          Card_content($$payload3, {
            class: "space-y-3",
            children: ($$payload4) => {
              Skeleton($$payload4, { class: "h-9 w-full" });
              $$payload4.out += `<!----> `;
              Skeleton($$payload4, { class: "h-9 w-full" });
              $$payload4.out += `<!----> `;
              Skeleton($$payload4, { class: "h-4 w-3/4" });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <!---->`;
          Card_footer($$payload3, {
            children: ($$payload4) => {
              Skeleton($$payload4, { class: "h-10 w-full rounded" });
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    }
    $$payload2.out += `<!--]--> <div class="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">By clicking Login, you agree to our <a href="/">Terms of Service</a> and <a href="##">Privacy Policy</a>.</div></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CIxw4R0v.js.map
