import { p as push, e as pop } from './index3-OytlP0AJ.js';
import { C as Card, a as Card_header, c as Card_title, b as Card_content } from './card-title-WUTiggGG.js';
import { p as page } from './index4-D0o29u-U.js';
import { B as Button } from './button-DVb50R-p.js';
import { A as Arrow_right } from './arrow-right-2FexVcmM.js';
import './utils-DnGaiUF2.js';
import './client-BIHfTmYE.js';
import './exports-B9zQMW2T.js';
import './Icon-YzG7RlkP.js';

function _page($$payload, $$props) {
  push();
  $$payload.out += `<div class="bg-muted flex min-h-[90dvh] flex-col items-center justify-center gap-6 p-5 md:p-10"><div class="bg-primary-foreground flex w-full max-w-sm flex-col gap-6">`;
  Card($$payload, {
    children: ($$payload2) => {
      Card_header($$payload2, {
        class: "text-center",
        children: ($$payload3) => {
          Card_title($$payload3, {
            class: "text-xl",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Configuration`;
            },
            $$slots: { default: true }
          });
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Card_content($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<div class="grid gap-x-6 gap-y-3"><div class="grid gap-6">`;
          Button($$payload3, {
            href: "/configuration",
            class: "bg-primary  flex from-white to-blue-400 hover:bg-gradient-to-r",
            children: ($$payload4) => {
              Arrow_right($$payload4, { class: "w-32 rotate-180" });
              $$payload4.out += `<!----> <h4 class="w-full text-end">Configuration</h4>`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----></div> <div class="grid gap-6">`;
          Button($$payload3, {
            href: page.url.pathname + "/ahu102",
            class: "bg-primary group flex from-white to-blue-400 hover:bg-gradient-to-r",
            children: ($$payload4) => {
              $$payload4.out += `<h4 class="group-hover:text-primary w-full text-start">Air Handling Unit 102</h4> `;
              Arrow_right($$payload4, { class: "rotate w-32" });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----></div> <div class="grid gap-6">`;
          Button($$payload3, {
            href: page.url.pathname + "/ahu103",
            class: "bg-primary group flex from-white to-blue-400 hover:bg-gradient-to-r",
            children: ($$payload4) => {
              $$payload4.out += `<h4 class="group-hover:text-primary w-full text-start">Air Handling Unit 103</h4> `;
              Arrow_right($$payload4, { class: "rotate w-32" });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----></div></div>`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div></div>`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-DpqRHu8A.js.map
