const index = 18;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BJetzVAT.js')).default;
const imports = ["_app/immutable/nodes/18.CIRhGmei.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B41hdK34.js","_app/immutable/chunks/BDwlTwo-.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js","_app/immutable/chunks/CCAte5Uw.js","_app/immutable/chunks/Cocm3y04.js","_app/immutable/chunks/BVFBc1gU.js","_app/immutable/chunks/B5_kf4jH.js","_app/immutable/chunks/MIwj1XX2.js","_app/immutable/chunks/DPibCUq0.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=18-BJKkvp_L.js.map
