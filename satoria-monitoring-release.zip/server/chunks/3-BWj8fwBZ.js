const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-DHkG_gkU.js')).default;
const imports = ["_app/immutable/nodes/3.Dznu5Bwr.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/OKggTVyC.js","_app/immutable/chunks/BZF4576O.js","_app/immutable/chunks/Ba1Xx48m.js","_app/immutable/chunks/CSrnH8IZ.js","_app/immutable/chunks/BSnVJNDa.js","_app/immutable/chunks/B3ZxWL9O.js","_app/immutable/chunks/CJfCnddR.js","_app/immutable/chunks/BOk-cWR7.js","_app/immutable/chunks/biFvaynu.js","_app/immutable/chunks/DQfRr7yB.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-BWj8fwBZ.js.map
