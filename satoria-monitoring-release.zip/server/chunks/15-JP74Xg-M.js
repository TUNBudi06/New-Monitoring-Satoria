const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DSZZ_eGT.js')).default;
const imports = ["_app/immutable/nodes/15.CfVmJ1IJ.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B41hdK34.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-JP74Xg-M.js.map
