const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-0yB81X2U.js')).default;
const imports = ["_app/immutable/nodes/0.BXOkRUbQ.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/OKggTVyC.js"];
const stylesheets = ["_app/immutable/assets/0.CTryqrm8.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-BlkehF5d.js.map
