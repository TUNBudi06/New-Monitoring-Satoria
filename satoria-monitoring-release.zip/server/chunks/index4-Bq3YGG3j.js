import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { pgTable, timestamp, varchar, pgEnum, serial, json, integer } from 'drizzle-orm/pg-core';
import { z } from 'zod';
import { D as DATABASE_URL } from './private-a70Od6j7.js';

const role = pgEnum("role", ["admin", "user"]);
const users = pgTable("user", {
  id: serial("id").primaryKey(),
  username: varchar("username").unique().notNull(),
  firstname: varchar("name").notNull(),
  lastname: varchar("surname").notNull(),
  email: varchar("email").unique().notNull(),
  password: varchar("password").notNull(),
  role: role().notNull().default("user"),
  initial: varchar("inisial", { length: 10 }),
  job_title: varchar("job_title"),
  // this for cookies to remember token if user check remember me
  rememberMe: varchar("remember_me"),
  createdAt: timestamp().defaultNow().notNull(),
  updatedAt: timestamp().defaultNow(),
  deletedAt: timestamp()
});
const sessions = pgTable("session", {
  id: varchar("id", { length: 255 }).primaryKey(),
  user_id: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  net_address: varchar(),
  user_agent: varchar(),
  payload: json(),
  expired: timestamp(),
  last_activity: timestamp(),
  createdAt: timestamp().defaultNow().notNull()
});
const usersSchema = z.object({
  id: z.number(),
  username: z.string().min(1, "Username is required"),
  firstname: z.string().min(1, "First name is required"),
  lastname: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  role: z.enum(["user", "admin"]).default("user"),
  job_title: z.string().optional(),
  rememberMe: z.string().optional(),
  createdAt: z.date(),
  updatedAt: z.date().optional(),
  deletedAt: z.date().optional()
});
const sessionsSchema = z.object({
  id: z.string().min(1, "Session ID is required"),
  user_id: z.number(),
  net_address: z.string().optional(),
  user_agent: z.string().optional(),
  payload: z.record(z.any()).optional(),
  expired: z.date(),
  last_activity: z.date(),
  createdAt: z.date()
});
const schema = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  role,
  sessions,
  sessionsSchema,
  users,
  usersSchema
}, Symbol.toStringTag, { value: "Module" }));
const client = postgres(DATABASE_URL);
const db = drizzle(client, { schema });

export { db as d, sessions as s, users as u };
//# sourceMappingURL=index4-Bq3YGG3j.js.map
