import './client-Chw5mV5o.js';
import { s as superValidate, a as setError, m as message } from './memoize-4dA32NW1.js';
import './index-DHSpIlkf.js';
import 'zod';
import { z as zod } from './zod4-DuqeCOVW.js';
import { z } from 'zod/v4';
import { d as db, a as autoclave_config } from './index4-CQhZZcHY.js';
import { and, eq } from 'drizzle-orm';
import './exports-DJ-e4XgW.js';
import './index2-C_y23GpV.js';
import './index-server-DpxecShX.js';
import './app-8Apsod8E.js';
import './_commonjsHelpers-B85MJLTf.js';
import 'zod/v4/core';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-DXaAhYwL.js';

const temperatureAndMessage = {
  temp_low: z.number().default(0),
  temp_low_message: z.string().default(""),
  temp_high: z.number().default(0),
  temp_high_message: z.string().default("")
};
const pressureAndMessage = {
  pressure_low: z.number().default(0),
  pressure_low_message: z.string().default(""),
  pressure_high: z.number().default(0),
  pressure_high_message: z.string().default("")
};
const overtimeAndMessage = {
  overtime: z.number().default(0),
  overtime_message: z.string().default("")
};
const ATV_Settings = {
  Config: z.object({
    dataCount: z.number().min(1).default(1),
    dataBatching: z.number().min(1).max(100).default(1),
    alarm: z.object({
      prepare: z.boolean().default(false),
      filling: z.boolean().default(false),
      heating: z.boolean().default(false),
      sterilization: z.boolean().default(false),
      cooling: z.boolean().default(false),
      drain: z.boolean().default(false),
      end: z.boolean().default(false)
    }).nullable(),
    alarm_switch: z.boolean().default(false)
  }),
  Prepare: z.object({
    ...temperatureAndMessage,
    ...pressureAndMessage
  }),
  Filling: z.object({
    ...pressureAndMessage,
    ...overtimeAndMessage,
    delayNotificationAtStart: z.number().nullable(),
    delayNotificationAtEnd: z.number().nullable()
  }),
  Heating: z.object({
    ...temperatureAndMessage,
    ...pressureAndMessage,
    ...overtimeAndMessage,
    delayNotificationAtStart: z.number().nullable(),
    delayNotificationAtEnd: z.number().nullable()
  })
};

const load = async () => {
  const generalConfig = await db.select().from(autoclave_config).where(and(eq(autoclave_config.line, "line2"), eq(autoclave_config.machine, "atva"))).then((result) => result[0]);
  return {
    formConfig: superValidate(generalConfig, zod(ATV_Settings.Config)),
    formPrepare: superValidate(generalConfig.prepare, zod(ATV_Settings.Prepare)),
    formFilling: superValidate(generalConfig.filling, zod(ATV_Settings.Filling)),
    formHeating: superValidate(generalConfig.heating, zod(ATV_Settings.Heating)),
    NotificationEnableList: generalConfig.alarm
  };
};
const actions = {
  generalConfig: async (event) => {
    const form = await superValidate(event, zod(ATV_Settings.Config));
    if (!form.valid) {
      return setError(form, "Invalid form data");
    }
    const data = form.data;
    let resultMachine = await db.select().from(autoclave_config).where(and(eq(autoclave_config.line, "line2"), eq(autoclave_config.machine, "atva"))).then((result) => result[0]);
    if (!resultMachine) {
      resultMachine = await db.insert(autoclave_config).values({ ...data, line: "line2", machine: "atva" }).returning().then((result) => result[0]);
    } else {
      resultMachine = await db.update(autoclave_config).set(data).where(eq(autoclave_config.id, resultMachine.id)).returning().then((result) => result[0]);
    }
    return message(form, "Configuration saved successfully!");
  },
  prepareConfiguration: async (event) => {
    const form = await superValidate(event, zod(ATV_Settings.Prepare));
    if (!form.valid) {
      return setError(form, "Invalid form data");
    }
    const data = form.data;
    await db.update(autoclave_config).set({ prepare: data }).where(and(eq(autoclave_config.line, "line2"), eq(autoclave_config.machine, "atva")));
    return message(form, "Prepare configuration saved successfully!");
  },
  fillingConfiguration: async (event) => {
    const form = await superValidate(event, zod(ATV_Settings.Filling));
    if (!form.valid) {
      return setError(form, "Invalid form data");
    }
    const data = form.data;
    await db.update(autoclave_config).set({ filling: data }).where(and(eq(autoclave_config.line, "line2"), eq(autoclave_config.machine, "atva")));
    return message(form, "Filling configuration saved successfully!");
  },
  heatingConfiguration: async (event) => {
    const form = await superValidate(event, zod(ATV_Settings.Heating));
    if (!form.valid) {
      return setError(form, "Invalid form data");
    }
    const data = form.data;
    await db.update(autoclave_config).set({ heating: data }).where(and(eq(autoclave_config.line, "line2"), eq(autoclave_config.machine, "atva")));
    return message(form, "Heating configuration saved successfully!");
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BPxQlDe_.js')).default;
const server_id = "src/routes/(app)/configuration/line2/atva/+page.server.ts";
const imports = ["_app/immutable/nodes/12.CXyHhkzD.js","_app/immutable/chunks/CoPNo8Uw.js","_app/immutable/chunks/D2gFui-Z.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/CBBX3viM.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/Wq0LeURr.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DktTnN65.js","_app/immutable/chunks/BJlwnpKT.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/DzYA0N7_.js","_app/immutable/chunks/CxJc_Azy.js","_app/immutable/chunks/Dk72urO7.js","_app/immutable/chunks/CvlZlbrB.js","_app/immutable/chunks/B3qc7meF.js","_app/immutable/chunks/C92kijqc.js","_app/immutable/chunks/DF7EeHcX.js","_app/immutable/chunks/BMvp3DJu.js","_app/immutable/chunks/DUTBo3uO.js","_app/immutable/chunks/83YYTNZR.js","_app/immutable/chunks/CaXNUFM6.js","_app/immutable/chunks/5DgVfj62.js","_app/immutable/chunks/CNvlm4iD.js","_app/immutable/chunks/CUdRkPKR.js","_app/immutable/chunks/BXb5CDMn.js","_app/immutable/chunks/Brr_actg.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=12-C_1QLpUN.js.map
