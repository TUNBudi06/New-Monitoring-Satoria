import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { pgTable, timestamp, varchar, pgEnum, serial, json, integer } from 'drizzle-orm/pg-core';

const role = pgEnum("role", ["admin", "user"]);
const users = pgTable("user", {
  id: serial("id").primaryKey(),
  username: varchar("username").unique().notNull(),
  firstname: varchar("name").notNull(),
  lastname: varchar("surname").notNull(),
  email: varchar("email").unique().notNull(),
  password: varchar("password").notNull(),
  role: role().notNull().default("user"),
  avatar: varchar("avatar"),
  job_title: varchar("job_title"),
  // this for cookies to remember token if user check remember me
  rememberMe: varchar("remember_me"),
  createdAt: timestamp().defaultNow().notNull(),
  updatedAt: timestamp().defaultNow(),
  deletedAt: timestamp()
});
const sessions = pgTable("session", {
  id: varchar("id", { length: 255 }).primaryKey(),
  user_id: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  net_address: varchar(),
  user_agent: varchar(),
  payload: json(),
  expired: timestamp(),
  last_activity: timestamp(),
  createdAt: timestamp().defaultNow().notNull()
});
const schema = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  role,
  sessions,
  users
}, Symbol.toStringTag, { value: "Module" }));
const DATABASE_URL = "postgres://root:mysecretpassword@localhost:5432/local";
const PRIVATE_JWT_SECRET = "AhSy0PhSL2WkU7Yw4xbKEApR48+XJMqJ8y7X3CETqBmUDfsdtaAFKF/kH+6enJAKnx/koGlu2f1Vl2FIOwVeEw==";
const JWT_ALGORITHM = "HS512";
const SESSION_REMEMBER = "30";
const REFRESH_REMEMBER = "15m";
const client = postgres(DATABASE_URL);
const db = drizzle(client, { schema });

export { JWT_ALGORITHM as J, PRIVATE_JWT_SECRET as P, REFRESH_REMEMBER as R, SESSION_REMEMBER as S, db as d, sessions as s, users as u };
//# sourceMappingURL=index4-DfyHg8Ez.js.map
