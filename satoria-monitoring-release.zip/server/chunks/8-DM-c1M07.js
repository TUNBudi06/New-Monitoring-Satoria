const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-uFc04tD8.js')).default;
const imports = ["_app/immutable/nodes/8.BMFT7JIU.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/B3uzrfl-.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-DM-c1M07.js.map
