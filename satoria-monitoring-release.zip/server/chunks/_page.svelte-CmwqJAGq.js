import { p as push, e as pop, q as escape_html, f as spread_props } from './index3-OytlP0AJ.js';
import { C as Card, a as Card_header, c as Card_title, b as Card_content } from './card-title-WUTiggGG.js';
import { C as Card_description } from './card-description-Cx_wKyom.js';
import DeviceHelper from 'node-device-detector/helper.js';
import './client-BTQW8I7B.js';
import './zod-Chu8DiFJ.js';
import './index2-DHSpIlkf.js';
import './5-DY944Yr4.js';
import 'zod';
import './button-DVb50R-p.js';
import './Toaster.svelte_svelte_type_style_lang-_rH29HWh.js';
import { I as Icon } from './Icon-xU8aaf28.js';
import './utils-DnGaiUF2.js';
import './exports-B9zQMW2T.js';
import './index-server2-4V4BZ4ml.js';
import './stringify-nj1_0ECd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './index-C6qlw1oi.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';
import 'node-device-detector';
import 'drizzle-orm';
import 'bcrypt';
import './index-server-DH7p7JOq.js';

function Monitor_check($$payload, $$props) {
  push();
  let { $$slots, $$events, ...props } = $$props;
  const iconNode = [
    ["path", { "d": "m9 10 2 2 4-4" }],
    [
      "rect",
      {
        "width": "20",
        "height": "14",
        "x": "2",
        "y": "3",
        "rx": "2"
      }
    ],
    ["path", { "d": "M12 17v4" }],
    ["path", { "d": "M8 21h8" }]
  ];
  Icon($$payload, spread_props([
    { name: "monitor-check" },
    props,
    {
      iconNode,
      children: ($$payload2) => {
        props.children?.($$payload2);
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
  pop();
}
function Shield_question($$payload, $$props) {
  push();
  let { $$slots, $$events, ...props } = $$props;
  const iconNode = [
    [
      "path",
      {
        "d": "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"
      }
    ],
    [
      "path",
      { "d": "M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3" }
    ],
    ["path", { "d": "M12 17h.01" }]
  ];
  Icon($$payload, spread_props([
    { name: "shield-question" },
    props,
    {
      iconNode,
      children: ($$payload2) => {
        props.children?.($$payload2);
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
  pop();
}
function Smartphone($$payload, $$props) {
  push();
  let { $$slots, $$events, ...props } = $$props;
  const iconNode = [
    [
      "rect",
      {
        "width": "14",
        "height": "20",
        "x": "5",
        "y": "2",
        "rx": "2",
        "ry": "2"
      }
    ],
    ["path", { "d": "M12 18h.01" }]
  ];
  Icon($$payload, spread_props([
    { name: "smartphone" },
    props,
    {
      iconNode,
      children: ($$payload2) => {
        props.children?.($$payload2);
        $$payload2.out += `<!---->`;
      },
      $$slots: { default: true }
    }
  ]));
  pop();
}
function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  $$payload.out += `<!---->`;
  Card($$payload, {
    class: "w-full",
    children: ($$payload2) => {
      $$payload2.out += `<!---->`;
      Card_header($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card_title($$payload3, {
            children: ($$payload4) => {
              $$payload4.out += `<!---->Account`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <!---->`;
          Card_description($$payload3, {
            children: ($$payload4) => {
              $$payload4.out += `<!---->Manage your account settings and preferences.`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> <!---->`;
      Card_content($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<!---->`;
          Card($$payload3, {
            children: ($$payload4) => {
              $$payload4.out += `<!---->`;
              Card_header($$payload4, {
                children: ($$payload5) => {
                  $$payload5.out += `<!---->`;
                  Card_title($$payload5, {
                    children: ($$payload6) => {
                      $$payload6.out += `<!---->Device Information`;
                    },
                    $$slots: { default: true }
                  });
                  $$payload5.out += `<!---->`;
                },
                $$slots: { default: true }
              });
              $$payload4.out += `<!----> <!---->`;
              Card_content($$payload4, {
                class: "space-y-3",
                children: ($$payload5) => {
                  $$payload5.out += `<div class="flex flex-col md:flex-row"><div class="flex-none items-center justify-center">`;
                  if (DeviceHelper.isDesktop(data.device) === true) {
                    $$payload5.out += "<!--[-->";
                    Monitor_check($$payload5, { class: "size-30 w-full md:size-40 lg:size-60" });
                  } else if (DeviceHelper.isMobile(data.device) === true) {
                    $$payload5.out += "<!--[1-->";
                    Smartphone($$payload5, { class: "m-0 size-25 w-full p-0" });
                  } else {
                    $$payload5.out += "<!--[!-->";
                    Shield_question($$payload5, { class: "lg:60 size-25 w-full md:size-40" });
                  }
                  $$payload5.out += `<!--]--></div> <div class="flex-auto"><div class="text-muted-foreground ps-3 text-start text-sm md:text-lg"><p class="font-semibold">Device Type: ${escape_html(data.device.device.type)}</p> <p class="font-semibold">Device Brand: ${escape_html(data.device.device.brand || "-")}</p> <p class="font-semibold">Device Model: ${escape_html(data.device.device.model || "-")}</p> <p class="font-semibold">Operating System: ${escape_html(data.device.os.name)}
								${escape_html(data.device.os.version)}
								${escape_html(data.device.os.platform)}</p></div></div></div>`;
                },
                $$slots: { default: true }
              });
              $$payload4.out += `<!---->`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <div class="flex flex-col gap-x-2 gap-y-4 pt-4 lg:flex-row">`;
          {
            $$payload3.out += "<!--[!-->";
          }
          $$payload3.out += `<!--]--></div>`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!---->`;
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-CmwqJAGq.js.map
