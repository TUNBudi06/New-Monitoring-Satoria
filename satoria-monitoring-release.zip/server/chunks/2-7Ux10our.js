const load = async ({ locals }) => {
  return {
    user: "budi"
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CRox6U3d.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.SUCjXFOc.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/DMzBSWS0.js","_app/immutable/chunks/D-A_H2yJ.js","_app/immutable/chunks/BTTR7cSe.js","_app/immutable/chunks/CvhWP5Ll.js","_app/immutable/chunks/BQFXtdII.js","_app/immutable/chunks/je7EIwxK.js","_app/immutable/chunks/CNPJXPZ7.js","_app/immutable/chunks/BL3iyit4.js","_app/immutable/chunks/CnZN1hIZ.js","_app/immutable/chunks/DDrWc_4L.js","_app/immutable/chunks/DSQ_1cCE.js","_app/immutable/chunks/CeNUQTqR.js","_app/immutable/chunks/DDygTKsk.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-7Ux10our.js.map
