const index = 3;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-Dw86N9m3.js')).default;
const imports = ["_app/immutable/nodes/3.CtgxgNeR.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/niT0dDKO.js","_app/immutable/chunks/o2QMK_dP.js","_app/immutable/chunks/Dmsp1KAm.js","_app/immutable/chunks/Cn7nNa4a.js","_app/immutable/chunks/Da_yRHvE.js","_app/immutable/chunks/DaoVg8md.js","_app/immutable/chunks/f0AS_gFo.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=3-CXgr7MVh.js.map
