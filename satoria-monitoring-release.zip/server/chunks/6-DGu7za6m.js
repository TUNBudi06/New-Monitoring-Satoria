const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bv-TcfgV.js')).default;
const imports = ["_app/immutable/nodes/6.nSPY-amh.js","_app/immutable/chunks/DbirDcMl.js","_app/immutable/chunks/D3ZwLoxx.js","_app/immutable/chunks/Cv85WRB7.js","_app/immutable/chunks/Bq6hNrG3.js","_app/immutable/chunks/DMzBSWS0.js","_app/immutable/chunks/BTTR7cSe.js","_app/immutable/chunks/CvhWP5Ll.js","_app/immutable/chunks/BQFXtdII.js","_app/immutable/chunks/je7EIwxK.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=6-DGu7za6m.js.map
