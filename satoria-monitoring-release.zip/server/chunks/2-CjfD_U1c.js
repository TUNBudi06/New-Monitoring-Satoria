const load = async ({ locals }) => {
  return {
    user: "budi"
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CfhDPMKj.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.BUN_vaS5.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/ByuCpQji.js","_app/immutable/chunks/0s6GNCna.js","_app/immutable/chunks/BD0PCi7w.js","_app/immutable/chunks/Bl_P7zlk.js","_app/immutable/chunks/apuB4Uj0.js","_app/immutable/chunks/BTliYN56.js","_app/immutable/chunks/D5R5meCU.js","_app/immutable/chunks/BDXrhozL.js","_app/immutable/chunks/Dm3VEKVN.js","_app/immutable/chunks/h9yqfu6I.js","_app/immutable/chunks/gK-5M4dR.js","_app/immutable/chunks/B4emce5D.js","_app/immutable/chunks/pyrCOowR.js","_app/immutable/chunks/DWNFJWvP.js","_app/immutable/chunks/CnAWw9Yu.js","_app/immutable/chunks/_dHSfhhN.js","_app/immutable/chunks/DteIz13L.js","_app/immutable/chunks/tUpKhWA1.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-CjfD_U1c.js.map
