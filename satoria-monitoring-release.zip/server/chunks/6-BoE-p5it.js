import { d as db, u as users } from './index4-Bq3YGG3j.js';
import { z } from 'zod';
import { c as createColumnHelper } from './index-B79SqP-N.js';
import './client-BYfstKI-.js';
import { s as superValidate, z as zod } from './zod-B9fgBnn4.js';
import './index-DHSpIlkf.js';
import { desc } from 'drizzle-orm';

const UserZodObject = z.object({
  username: z.string().min(1, "Username is required"),
  firstname: z.string().min(1, "First name is required"),
  lastname: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirm_password: z.string().min(6, "Confirm password must be at least 6 characters"),
  role: z.enum(["user", "admin"]).default("user"),
  job_title: z.string()
});
const FormChangePasswordZodObject = z.object({
  id: z.number().nullish(),
  new_password: z.string().min(6, "New password must be at least 6 characters"),
  confirm_password: z.string().min(6, "Confirm password must be at least 6 characters")
});
const FormChangeAccountZodObject = z.object({
  id: z.number().nullish(),
  username: z.string().min(1, "Username is required"),
  email: z.string().email("Invalid email address")
});
const columnHelper = createColumnHelper();
const ColumnsFormat = [
  columnHelper.accessor("id", {
    header: "ID",
    cell: (info) => info.getValue().toString(),
    size: 50
  }),
  columnHelper.accessor("username", {
    header: "Username",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("firstname", {
    header: "First Name",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("lastname", {
    header: "Last Name",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("email", {
    header: "Email",
    cell: (info) => info.getValue(),
    size: 200
  }),
  columnHelper.accessor("role", {
    header: "Role",
    cell: (info) => info.getValue(),
    size: 100
  }),
  columnHelper.accessor("job_title", {
    header: "Job Title",
    cell: (info) => info.getValue(),
    size: 150
  }),
  columnHelper.accessor("createdAt", {
    header: "Created At",
    cell: (info) => info.getValue().toLocaleString(),
    size: 200
  }),
  columnHelper.accessor("updatedAt", {
    header: "Updated At",
    cell: (info) => info.getValue()?.toLocaleString() || "N/A",
    size: 200
  }),
  columnHelper.accessor("deletedAt", {
    header: "Deleted At",
    cell: (info) => info.getValue()?.toLocaleString() || "N/A",
    size: 200
  }),
  columnHelper.display({
    id: "actions",
    header: "Actions",
    size: 150
  })
];

const load = async () => {
  const [user, AA, CC, CP] = await Promise.all([
    await db.select().from(users).orderBy(desc(users.createdAt)),
    await superValidate(zod(UserZodObject)),
    await superValidate(zod(FormChangeAccountZodObject)),
    await superValidate(zod(FormChangePasswordZodObject))
  ]);
  return {
    users: user,
    formAA: AA,
    formCC: CC,
    formCP: CP
  };
};
const actions = {
  create: (event) => {
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 6;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-mdjOZFnx.js')).default;
const server_id = "src/routes/(app)/account/admin/+page.server.ts";
const imports = ["_app/immutable/nodes/6.C2mm0FLw.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/B5_kf4jH.js","_app/immutable/chunks/CCAte5Uw.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js","_app/immutable/chunks/Cocm3y04.js","_app/immutable/chunks/BdMBCV5W.js","_app/immutable/chunks/C-4QqHf3.js","_app/immutable/chunks/YFp1XVmH.js","_app/immutable/chunks/BDwlTwo-.js","_app/immutable/chunks/Bc0mjKXN.js","_app/immutable/chunks/BdokIwwV.js","_app/immutable/chunks/jOYcctrt.js","_app/immutable/chunks/DkjyHJ0x.js","_app/immutable/chunks/DPibCUq0.js","_app/immutable/chunks/BVFBc1gU.js","_app/immutable/chunks/MIwj1XX2.js","_app/immutable/chunks/B41hdK34.js","_app/immutable/chunks/DtBtvVQy.js","_app/immutable/chunks/W6geA9Qm.js","_app/immutable/chunks/DtYRfcXW.js","_app/immutable/chunks/ChGWCNSl.js","_app/immutable/chunks/KkXcApc5.js","_app/immutable/chunks/CNDr1Z7s.js","_app/immutable/chunks/BHHNCoHP.js"];
const stylesheets = [];
const fonts = [];

var _6 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  component: component,
  fonts: fonts,
  imports: imports,
  index: index,
  server: _page_server_ts,
  server_id: server_id,
  stylesheets: stylesheets
});

export { ColumnsFormat as C, _6 as _ };
//# sourceMappingURL=6-BoE-p5it.js.map
