import { p as push, e as pop, k as spread_attributes, l as clsx, u as bind_props, q as escape_html } from './index2-DUnQqHl4.js';
import { p as page } from './index3-CiFuucos.js';
import { B as Button } from './button-C5sHZXZh.js';
import { C as Card, a as Card_header, b as Card_content, c as Card_title } from './card-title-BYq8CNoN.js';
import { C as Card_description } from './card-description-o_4N8xsi.js';
import { c as cn } from './utils-kqvSmeHv.js';
import './client-4wmd_MHx.js';
import './exports-Bob2A8Cd.js';

function Card_footer($$payload, $$props) {
  push();
  let {
    ref = null,
    class: className,
    children,
    $$slots,
    $$events,
    ...restProps
  } = $$props;
  $$payload.out += `<div${spread_attributes(
    {
      "data-slot": "card-footer",
      class: clsx(cn("flex items-center px-6 [.border-t]:pt-6", className)),
      ...restProps
    },
    null
  )}>`;
  children?.($$payload);
  $$payload.out += `<!----></div>`;
  bind_props($$props, { ref });
  pop();
}
function _error($$payload, $$props) {
  push();
  $$payload.out += `<div class="bg-muted flex min-h-svh flex-col items-center justify-center gap-10 p-5 md:p-10"><div class="bg-primary-foreground flex w-full max-w-[18rem] flex-col gap-10">`;
  Card($$payload, {
    children: ($$payload2) => {
      Card_header($$payload2, {
        class: "text-center",
        children: ($$payload3) => {
          Card_title($$payload3, {
            class: "text-xl",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Error ${escape_html(page.status)}`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> `;
          Card_description($$payload3, {
            class: "text-muted-foreground",
            children: ($$payload4) => {
              $$payload4.out += `<!---->${escape_html(page.error?.message)}`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Card_content($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<h3 class="text-lg font-semibold">Something went wrong</h3> <h5 class="text-muted-foreground">Route: ${escape_html(page.url.pathname)} (Error)</h5>`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Card_footer($$payload2, {
        class: "justify-center text-center",
        children: ($$payload3) => {
          Button($$payload3, {
            href: page.url.origin,
            class: "w-full max-w-sm",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Dashboard`;
            },
            $$slots: { default: true }
          });
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div></div>`;
  pop();
}

export { _error as default };
//# sourceMappingURL=_error.svelte-CWy7D4zt.js.map
