const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BMvKVNpM.js')).default;
const imports = ["_app/immutable/nodes/7.BpohP5Ez.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/A10nGaqm.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=7-DTgHPoPK.js.map
