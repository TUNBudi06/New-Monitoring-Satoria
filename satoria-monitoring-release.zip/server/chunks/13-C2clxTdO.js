const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Cm457UQq.js')).default;
const imports = ["_app/immutable/nodes/13.D0RSvndd.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/B3uzrfl-.js","_app/immutable/chunks/9lx5pHay.js","_app/immutable/chunks/OKggTVyC.js","_app/immutable/chunks/B3ZxWL9O.js","_app/immutable/chunks/CSrnH8IZ.js","_app/immutable/chunks/BSnVJNDa.js","_app/immutable/chunks/4fFwGPg6.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=13-C2clxTdO.js.map
