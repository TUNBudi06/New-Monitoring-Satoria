import { p as push, w as copy_payload, x as assign_payload, e as pop } from './index3-OytlP0AJ.js';
import './button-DVb50R-p.js';
import { e as emailSchema, u as usernameSchema } from './17-BsHMwDA7.js';
import './client-BTQW8I7B.js';
import { b as superForm, c as zodClient } from './zod-Chu8DiFJ.js';
import './index2-DHSpIlkf.js';
import './Toaster.svelte_svelte_type_style_lang-_rH29HWh.js';
import './utils-DnGaiUF2.js';
import 'zod';
import './index-C6qlw1oi.js';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-a70Od6j7.js';
import 'drizzle-orm';
import 'bcrypt';
import 'crypto';
import './exports-B9zQMW2T.js';
import './index-server2-4V4BZ4ml.js';
import './stringify-nj1_0ECd.js';
import './_commonjsHelpers-B85MJLTf.js';
import './index-server-DH7p7JOq.js';

function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  superForm(data.email, { validators: zodClient(emailSchema) });
  superForm(data.username, { validators: zodClient(usernameSchema) });
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="flex flex-col gap-6">`;
    {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> <div class="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">By clicking Login, you agree to our <a href="/">Terms of Service</a> and <a href="##">Privacy Policy</a>.</div></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}

export { _page as default };
//# sourceMappingURL=_page.svelte-7-b2zRnx.js.map
