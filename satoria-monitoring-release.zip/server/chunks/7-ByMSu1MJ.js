import { d as db, s as sessions } from './index4-Bq3YGG3j.js';
import { eq } from 'drizzle-orm';
import deviceDetector from 'node-device-detector';
import * as crypto from 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'zod';
import './private-a70Od6j7.js';

const load = async (event) => {
  const jwt_string = await new Promise((resolve, reject) => {
    const cookie = event.cookies.get("refresh_token");
    if (cookie) {
      resolve(cookie);
    } else {
      reject(new Error("No refresh token found"));
    }
  }).then((cookie) => {
    return event.locals.jwt.decode(cookie);
  });
  const sessionDevice = await new Promise((resolve, reject) => {
    const sessionList = db.select().from(sessions).where(eq(sessions.user_id, jwt_string.user_id));
    if (!sessionList) {
      return reject([]);
    }
    return resolve(sessionList);
  }).then((sessionList) => {
    return sessionList.map((session, index) => {
      return {
        now: session.payload?._token === jwt_string.id,
        id: index,
        token: session.id,
        last_activity: session.last_activity,
        type: new deviceDetector().detect(session.user_agent ?? "").device.type,
        address: session.net_address ?? "Unknown"
      };
    });
  });
  return {
    sessionDevice
  };
};
const actions = {
  invoke: async (event) => {
    const formData = await event.request.formData();
    const id = formData.get("id");
    const randomData = crypto.randomBytes(32).toString("hex");
    const sessiondb = await db.select().from(sessions).where(eq(sessions.id, id)).then((session) => session[0]);
    if (!sessiondb) {
      return { success: true, message: "Session not found", error: true };
    }
    sessiondb.payload._token = randomData;
    await db.update(sessions).set(sessiondb).where(eq(sessions.id, id));
    return { success: true, message: "Device actions invoked successfully", error: false };
  },
  delete: async (event) => {
    const formData = await event.request.formData();
    const id = formData.get("id");
    await db.delete(sessions).where(eq(sessions.id, id));
    return { success: true, message: "session actions deleted successfully", error: false };
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-D91gVsxk.js')).default;
const server_id = "src/routes/(app)/account/devices/+page.server.ts";
const imports = ["_app/immutable/nodes/7.XdFpaKME.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/B5_kf4jH.js","_app/immutable/chunks/CCAte5Uw.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js","_app/immutable/chunks/Cocm3y04.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/BdMBCV5W.js","_app/immutable/chunks/C-4QqHf3.js","_app/immutable/chunks/YFp1XVmH.js","_app/immutable/chunks/BDwlTwo-.js","_app/immutable/chunks/B9LemL8W.js","_app/immutable/chunks/MIwj1XX2.js","_app/immutable/chunks/DPibCUq0.js","_app/immutable/chunks/W6geA9Qm.js","_app/immutable/chunks/DtYRfcXW.js","_app/immutable/chunks/ChGWCNSl.js","_app/immutable/chunks/KkXcApc5.js","_app/immutable/chunks/CgLEbebT.js","_app/immutable/chunks/CNDr1Z7s.js","_app/immutable/chunks/Bc0mjKXN.js","_app/immutable/chunks/Doo5YQIh.js","_app/immutable/chunks/B41hdK34.js"];
const stylesheets = ["_app/immutable/assets/Toaster.D7TgzYVC.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=7-ByMSu1MJ.js.map
