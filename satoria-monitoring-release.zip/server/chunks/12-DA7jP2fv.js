const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-Bpnszj6D.js')).default;
const imports = ["_app/immutable/nodes/12.D3_PVrGD.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/BvWSGiVL.js","_app/immutable/chunks/CrQ87Cea.js","_app/immutable/chunks/Y9se7Tnw.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/C5SJzsNr.js","_app/immutable/chunks/Bghoqm9w.js","_app/immutable/chunks/lh_9_4g0.js","_app/immutable/chunks/DKdIxulT.js","_app/immutable/chunks/CEdTP3zb.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/mYIg1c-4.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/DGXqUrp0.js","_app/immutable/chunks/DhVlZ8Zk.js","_app/immutable/chunks/BgmoFf8y.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=12-DA7jP2fv.js.map
