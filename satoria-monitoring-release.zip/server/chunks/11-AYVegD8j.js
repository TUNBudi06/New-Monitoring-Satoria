const index = 11;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BZTUT2Yf.js')).default;
const imports = ["_app/immutable/nodes/11.BMFT7JIU.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/B3uzrfl-.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=11-AYVegD8j.js.map
