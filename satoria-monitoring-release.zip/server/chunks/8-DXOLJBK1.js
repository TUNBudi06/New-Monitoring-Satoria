const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-uFc04tD8.js')).default;
const imports = ["_app/immutable/nodes/8.CXaUo1si.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/DuSXapKN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-DXOLJBK1.js.map
