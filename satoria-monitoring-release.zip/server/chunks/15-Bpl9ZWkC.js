const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CLJhqDmT.js')).default;
const imports = ["_app/immutable/nodes/15.CSVxmezq.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/A10nGaqm.js","_app/immutable/chunks/Dm3VEKVN.js","_app/immutable/chunks/ByuCpQji.js","_app/immutable/chunks/BDXrhozL.js","_app/immutable/chunks/BD0PCi7w.js","_app/immutable/chunks/Bl_P7zlk.js","_app/immutable/chunks/apuB4Uj0.js","_app/immutable/chunks/BTliYN56.js","_app/immutable/chunks/DKRMv3x7.js","_app/immutable/chunks/CSMLMftt.js","_app/immutable/chunks/DL5dVUYN.js","_app/immutable/chunks/0s6GNCna.js","_app/immutable/chunks/h9yqfu6I.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-Bpl9ZWkC.js.map
