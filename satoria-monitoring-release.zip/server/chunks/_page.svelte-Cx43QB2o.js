import { B as Button } from './button-CCIPjM88.js';
import { C as Card, a as Card_header, c as Card_title, b as Card_content } from './card-title-BDMyfjba.js';
import { C as Card_description } from './card-description-CDxgs-cs.js';
import { L as Label, I as Input } from './label-B1-cCnbe.js';
import './context-CxLGWIzu.js';
import './utils-DDhKetno.js';
import './use-id-CFhzCeK-.js';

function _page($$payload) {
  $$payload.out += `<div class="flex flex-col gap-6">`;
  Card($$payload, {
    children: ($$payload2) => {
      Card_header($$payload2, {
        class: "text-center",
        children: ($$payload3) => {
          Card_title($$payload3, {
            class: "text-xl",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Welcome back`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> `;
          Card_description($$payload3, {
            children: ($$payload4) => {
              $$payload4.out += `<!---->Login with your account`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Card_content($$payload2, {
        children: ($$payload3) => {
          $$payload3.out += `<form><div class="grid gap-6"><div class="grid gap-6"><div class="grid gap-3">`;
          Label($$payload3, {
            for: "email",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Email`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> `;
          Input($$payload3, {
            id: "email",
            type: "email",
            placeholder: "m@example.com",
            required: true
          });
          $$payload3.out += `<!----></div> <div class="grid gap-3"><div class="flex items-center">`;
          Label($$payload3, {
            for: "password",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Password`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----> <a href="/forgot" class="ml-auto text-sm underline-offset-4 hover:underline">Forgot your password?</a></div> `;
          Input($$payload3, {
            id: "password",
            type: "password",
            required: true
          });
          $$payload3.out += `<!----></div> `;
          Button($$payload3, {
            type: "submit",
            class: "w-full",
            children: ($$payload4) => {
              $$payload4.out += `<!---->Login`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!----></div> <div class="text-center text-sm">Don't have an account? Contact Admin</div></div></form>`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!---->`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> <div class="text-muted-foreground *:[a]:hover:text-primary text-center text-xs text-balance *:[a]:underline *:[a]:underline-offset-4">By clicking Login, you agree to our <a href="/">Terms of Service</a> and <a href="##">Privacy Policy</a>.</div></div>`;
}

export { _page as default };
//# sourceMappingURL=_page.svelte-Cx43QB2o.js.map
