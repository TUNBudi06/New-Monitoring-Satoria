import { d as db, u as users } from './index-C6qlw1oi.js';
import { eq } from 'drizzle-orm';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'zod';
import './private-a70Od6j7.js';

const load = async (event) => {
  const jwt_cookie = event.cookies.get("refresh_token");
  let user;
  try {
    const payload = event.locals.jwt.decode(jwt_cookie);
    user = await db.select({
      username: users.username,
      email: users.email,
      firstname: users.firstname,
      lastname: users.lastname,
      type: users.role
    }).from(users).where(eq(users.id, payload.user_id)).limit(1).then((res) => res[0]);
  } catch (e) {
    console.error("JWT decode error:", e);
  }
  return {
    user: user || null
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CLTwjxWT.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.B4BtE3Nu.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/Y9se7Tnw.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/D1GQsrue.js","_app/immutable/chunks/C5SJzsNr.js","_app/immutable/chunks/Bghoqm9w.js","_app/immutable/chunks/Ck2fqhG2.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/mYIg1c-4.js","_app/immutable/chunks/D44Zoka0.js","_app/immutable/chunks/COfIiwau.js","_app/immutable/chunks/BisprqW_.js","_app/immutable/chunks/Nzqr8m1V.js","_app/immutable/chunks/xCbqk_GY.js","_app/immutable/chunks/D3Q3_Xcg.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/DhVlZ8Zk.js","_app/immutable/chunks/BgmoFf8y.js","_app/immutable/chunks/B68HRNZJ.js","_app/immutable/chunks/lh_9_4g0.js","_app/immutable/chunks/DKdIxulT.js","_app/immutable/chunks/CEdTP3zb.js","_app/immutable/chunks/Hu11wkTB.js","_app/immutable/chunks/Bpa_vOvn.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-FJBx5xjI.js.map
