import './index-DwrKR0Y-.js';
import { P as PRIVATE_JWT_SECRET, d as db, s as sessions, S as SESSION_REMEMBER, R as REFRESH_REMEMBER, J as JWT_ALGORITHM } from './index4-DfyHg8Ez.js';
import { eq } from 'drizzle-orm';
import * as jwtm from 'jose';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';

function sequence(...handlers) {
  const length = handlers.length;
  if (!length) return ({ event, resolve }) => resolve(event);
  return ({ event, resolve }) => {
    return apply_handle(0, event, {});
    function apply_handle(i, event2, parent_options) {
      const handle2 = handlers[i];
      return handle2({
        event: event2,
        resolve: (event3, options) => {
          const transformPageChunk = async ({ html, done }) => {
            if (options?.transformPageChunk) {
              html = await options.transformPageChunk({ html, done }) ?? "";
            }
            if (parent_options?.transformPageChunk) {
              html = await parent_options.transformPageChunk({ html, done }) ?? "";
            }
            return html;
          };
          const filterSerializedResponseHeaders = parent_options?.filterSerializedResponseHeaders ?? options?.filterSerializedResponseHeaders;
          const preload = parent_options?.preload ?? options?.preload;
          return i < length - 1 ? apply_handle(i + 1, event3, {
            transformPageChunk,
            filterSerializedResponseHeaders,
            preload
          }) : resolve(event3, { transformPageChunk, filterSerializedResponseHeaders, preload });
        }
      });
    }
  };
}
async function setIPSession(event, session) {
  const IP = event.getClientAddress();
  return await db.update(sessions).set({ net_address: IP }).where(eq(sessions.id, session.id)).returning().then((res) => res[0]);
}
async function updateActivitySession(sessionID) {
  const now = /* @__PURE__ */ new Date();
  return await db.update(sessions).set({ last_activity: now }).where(eq(sessions.id, sessionID)).returning().then((res) => res[0]);
}
const auth = async ({ event, resolve }) => {
  if (event.route.id?.startsWith("/(app)")) ;
  return resolve(event);
};
const login = async ({ event, resolve }) => {
  if (event.url.pathname?.startsWith("/login")) {
    const jwt2 = event.cookies.get("refresh_token");
    if (jwt2) {
      try {
        const payload = await event.locals.jwt.verify(jwt2, Buffer.from(PRIVATE_JWT_SECRET, "base64")).then((res) => res.payload);
        event.locals.alreadysigned = "login";
      } catch (e) {
        const payload = e?.payload;
        const sessiondb = await db.select().from(sessions).where(eq(sessions.id, payload.token)).limit(1).then((res) => res[0]);
        if (!sessiondb) {
          return resolve(event);
        }
        if (!sessiondb.expired || new Date(sessiondb.expired) < /* @__PURE__ */ new Date()) {
          return resolve(event);
        }
        if (sessiondb.last_activity && new Date(sessiondb.last_activity) < new Date((/* @__PURE__ */ new Date()).getTime() - SESSION_REMEMBER * 24 * 60 * 60 * 1e3)) {
          console.log("session has not login for 30 days");
          event.locals.alreadysigned = "session_logout";
          return resolve(event);
        }
        await updateActivitySession(sessiondb.id);
        if (event.getClientAddress() != sessiondb.net_address) {
          await setIPSession(event, sessiondb);
        }
        if (sessiondb.payload?._token != payload.id) {
          return resolve(event);
        }
        const jwt_data = {
          id: sessiondb.payload?._token,
          token: sessiondb.id,
          user_id: sessiondb.user_id
        };
        const jwt22 = await new event.locals.jwt.sign(jwt_data).setExpirationTime(REFRESH_REMEMBER).setIssuedAt().setProtectedHeader({ alg: JWT_ALGORITHM, typ: "JWT" }).setIssuedAt().sign(Buffer.from(PRIVATE_JWT_SECRET, "base64"));
        event.cookies.set("refresh_token", jwt22, {
          path: "/",
          httpOnly: false,
          secure: false,
          sameSite: "strict"
        });
        event.locals.alreadysigned = "login";
      }
    }
  }
  return resolve(event);
};
const authincator = sequence(auth, login);
const jwt = async ({ event, resolve }) => {
  event.locals.jwt = {
    sign: jwtm.SignJWT,
    unsecuredJwt: jwtm.UnsecuredJWT,
    verify: jwtm.jwtVerify,
    decode: jwtm.decodeJwt
  };
  return resolve(event);
};
const devtool = async ({ event, resolve }) => {
  if (event.url.pathname.startsWith("/.well-known/appspecific/com.chrome.devtools")) {
    return new Response(null, { status: 204 });
  }
  return resolve(event);
};
const testingOnly = async ({ event, resolve }) => {
  return resolve(event);
};
const handle = sequence(jwt, devtool, authincator, testingOnly);

export { devtool, handle };
//# sourceMappingURL=hooks.server-VBq91bWY.js.map
