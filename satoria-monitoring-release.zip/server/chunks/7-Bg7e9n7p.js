import { d as db, s as sessions } from './index4-CQhZZcHY.js';
import { eq } from 'drizzle-orm';
import deviceDetector from 'node-device-detector';
import * as crypto from 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import './private-DXaAhYwL.js';

const load = async (event) => {
  const jwt_string = await new Promise((resolve, reject) => {
    const cookie = event.cookies.get("refresh_token");
    if (cookie) {
      resolve(cookie);
    } else {
      reject(new Error("No refresh token found"));
    }
  }).then((cookie) => {
    return event.locals.jwt.decode(cookie);
  });
  const sessionDevice = await new Promise((resolve, reject) => {
    const sessionList = db.select().from(sessions).where(eq(sessions.user_id, jwt_string.user_id));
    if (!sessionList) {
      return reject([]);
    }
    return resolve(sessionList);
  }).then((sessionList) => {
    return sessionList.map((session, index) => {
      return {
        now: session.payload?._token === jwt_string.id,
        id: index,
        token: session.id,
        last_activity: session.last_activity,
        type: new deviceDetector().detect(session.user_agent ?? "").device.type,
        address: session.net_address ?? "Unknown"
      };
    });
  });
  return {
    sessionDevice
  };
};
const actions = {
  invoke: async (event) => {
    const formData = await event.request.formData();
    const id = formData.get("id");
    const randomData = crypto.randomBytes(32).toString("hex");
    const sessiondb = await db.select().from(sessions).where(eq(sessions.id, id)).then((session) => session[0]);
    if (!sessiondb) {
      return { success: true, message: "Session not found", error: true };
    }
    sessiondb.payload._token = randomData;
    await db.update(sessions).set(sessiondb).where(eq(sessions.id, id));
    return { success: true, message: "Device actions invoked successfully", error: false };
  },
  delete: async (event) => {
    const formData = await event.request.formData();
    const id = formData.get("id");
    await db.delete(sessions).where(eq(sessions.id, id));
    return { success: true, message: "session actions deleted successfully", error: false };
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DS6Up2mR.js')).default;
const server_id = "src/routes/(app)/account/devices/+page.server.ts";
const imports = ["_app/immutable/nodes/7.zfGd8BED.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/BD5iuqaG.js","_app/immutable/chunks/0KEMEeca.js","_app/immutable/chunks/Wq0LeURr.js","_app/immutable/chunks/Dur87Fff.js","_app/immutable/chunks/BIeUyJGK.js","_app/immutable/chunks/DgBZ1MQI.js","_app/immutable/chunks/C7rFBrh4.js","_app/immutable/chunks/897_qMa7.js","_app/immutable/chunks/DktTnN65.js","_app/immutable/chunks/DrLhrU0H.js","_app/immutable/chunks/DUTBo3uO.js","_app/immutable/chunks/C7tyWe_Y.js","_app/immutable/chunks/BXb5CDMn.js","_app/immutable/chunks/CUt_RlLg.js","_app/immutable/chunks/CbL_9p7q.js","_app/immutable/chunks/88HccgOR.js","_app/immutable/chunks/BJlwnpKT.js","_app/immutable/chunks/DmRhQfWn.js","_app/immutable/chunks/DzYA0N7_.js","_app/immutable/chunks/CxJc_Azy.js","_app/immutable/chunks/Dk72urO7.js","_app/immutable/chunks/zUc9I7b_.js","_app/immutable/chunks/B3qc7meF.js","_app/immutable/chunks/lOueDxZy.js","_app/immutable/chunks/CaXNUFM6.js","_app/immutable/chunks/DF7EeHcX.js","_app/immutable/chunks/CUdRkPKR.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=7-Bg7e9n7p.js.map
