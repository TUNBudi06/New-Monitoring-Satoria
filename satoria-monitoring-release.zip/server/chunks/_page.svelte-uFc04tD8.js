function _page($$payload) {
  $$payload.out += `<h1>Welcome to SvelteKit</h1> <p>Visit <a href="https://svelte.dev/docs/kit">svelte.dev/docs/kit</a> to read the documentation</p>`;
}

export { _page as default };
//# sourceMappingURL=_page.svelte-uFc04tD8.js.map
