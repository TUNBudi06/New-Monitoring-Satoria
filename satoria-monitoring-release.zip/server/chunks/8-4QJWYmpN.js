const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-uFc04tD8.js')).default;
const imports = ["_app/immutable/nodes/8.DR3Ib5gL.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/DHUAlugP.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-4QJWYmpN.js.map
