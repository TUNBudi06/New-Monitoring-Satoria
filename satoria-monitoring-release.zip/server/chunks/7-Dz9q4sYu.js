import { d as db, s as sessions } from './index-C6qlw1oi.js';
import { eq } from 'drizzle-orm';
import deviceDetector from 'node-device-detector';
import * as crypto from 'node:crypto';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'zod';
import './private-a70Od6j7.js';

const load = async (event) => {
  const jwt_string = await new Promise((resolve, reject) => {
    const cookie = event.cookies.get("refresh_token");
    if (cookie) {
      resolve(cookie);
    } else {
      reject(new Error("No refresh token found"));
    }
  }).then((cookie) => {
    return event.locals.jwt.decode(cookie);
  });
  const sessionDevice = await new Promise((resolve, reject) => {
    const sessionList = db.select().from(sessions).where(eq(sessions.user_id, jwt_string.user_id));
    if (!sessionList) {
      return reject([]);
    }
    return resolve(sessionList);
  }).then((sessionList) => {
    return sessionList.map((session, index) => {
      return {
        now: session.payload?._token === jwt_string.id,
        id: index,
        token: session.id,
        last_activity: session.last_activity,
        type: new deviceDetector().detect(session.user_agent ?? "").device.type,
        address: session.net_address ?? "Unknown"
      };
    });
  });
  return {
    sessionDevice
  };
};
const actions = {
  invoke: async (event) => {
    const formData = await event.request.formData();
    const id = formData.get("id");
    const randomData = crypto.randomBytes(32).toString("hex");
    const sessiondb = await db.select().from(sessions).where(eq(sessions.id, id)).then((session) => session[0]);
    if (!sessiondb) {
      return { success: true, message: "Session not found", error: true };
    }
    sessiondb.payload._token = randomData;
    await db.update(sessions).set(sessiondb).where(eq(sessions.id, id));
    return { success: true, message: "Device actions invoked successfully", error: false };
  },
  delete: async (event) => {
    const formData = await event.request.formData();
    const id = formData.get("id");
    await db.delete(sessions).where(eq(sessions.id, id));
    return { success: true, message: "session actions deleted successfully", error: false };
  }
};

var _page_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  actions: actions,
  load: load
});

const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BlFi37eD.js')).default;
const server_id = "src/routes/(app)/account/devices/+page.server.ts";
const imports = ["_app/immutable/nodes/7.D9syvfwV.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/DWhOouKw.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/Bup8ca7u.js","_app/immutable/chunks/D1GQsrue.js","_app/immutable/chunks/CrQ87Cea.js","_app/immutable/chunks/Y9se7Tnw.js","_app/immutable/chunks/BkC8TGyw.js","_app/immutable/chunks/BSORQ3CZ.js","_app/immutable/chunks/C5SJzsNr.js","_app/immutable/chunks/Bghoqm9w.js","_app/immutable/chunks/ByJP-KLq.js","_app/immutable/chunks/YJ6feNwH.js","_app/immutable/chunks/BgmoFf8y.js","_app/immutable/chunks/Ck2fqhG2.js","_app/immutable/chunks/mYIg1c-4.js","_app/immutable/chunks/LoX4kafq.js","_app/immutable/chunks/COfIiwau.js","_app/immutable/chunks/BisprqW_.js","_app/immutable/chunks/Nzqr8m1V.js","_app/immutable/chunks/xCbqk_GY.js","_app/immutable/chunks/D3Q3_Xcg.js","_app/immutable/chunks/B2XLuyqE.js","_app/immutable/chunks/PEZGSbjs.js","_app/immutable/chunks/D0WhWLe0.js","_app/immutable/chunks/69_IOA4Y.js"];
const stylesheets = ["_app/immutable/assets/Toaster.D7TgzYVC.css"];
const fonts = [];

export { component, fonts, imports, index, _page_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=7-Dz9q4sYu.js.map
