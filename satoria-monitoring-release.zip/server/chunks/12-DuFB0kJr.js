const index = 12;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CPWFt9j8.js')).default;
const imports = ["_app/immutable/nodes/12.DR3Ib5gL.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/DHUAlugP.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=12-DuFB0kJr.js.map
