const index = 8;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-uFc04tD8.js')).default;
const imports = ["_app/immutable/nodes/8.BpohP5Ez.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/A10nGaqm.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=8-DaILURhW.js.map
