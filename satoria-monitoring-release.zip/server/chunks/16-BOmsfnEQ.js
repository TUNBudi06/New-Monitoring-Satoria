const index = 16;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-CPWFt9j8.js')).default;
const imports = ["_app/immutable/nodes/16.CIV-fHBG.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/83YYTNZR.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=16-BOmsfnEQ.js.map
