import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { pgTable, timestamp, varchar, pgEnum, serial, json, integer, boolean } from 'drizzle-orm/pg-core';
import { D as DATABASE_URL } from './private-a70Od6j7.js';

const role = pgEnum("role", ["admin", "user"]);
const users = pgTable("user", {
  id: serial("id").primaryKey(),
  username: varchar("username").unique().notNull(),
  firstname: varchar("name").notNull(),
  lastname: varchar("surname").notNull(),
  email: varchar("email").unique().notNull(),
  password: varchar("password").notNull(),
  role: role().notNull().default("user"),
  initial: varchar("inisial", { length: 10 }),
  job_title: varchar("job_title"),
  // this for cookies to remember token if user check remember me
  rememberMe: varchar("remember_me"),
  createdAt: timestamp().defaultNow().notNull(),
  updatedAt: timestamp().defaultNow(),
  deletedAt: timestamp()
});
const sessions = pgTable("session", {
  id: varchar("id", { length: 255 }).primaryKey(),
  user_id: integer("user_id").references(() => users.id, { onDelete: "cascade" }),
  net_address: varchar(),
  user_agent: varchar(),
  payload: json(),
  expired: timestamp(),
  last_activity: timestamp(),
  createdAt: timestamp().defaultNow().notNull()
});
const autoclave_config = pgTable("autoclave_config", {
  id: serial("id").primaryKey(),
  line: varchar("line", { length: 10 }).notNull(),
  machine: varchar("machine", { length: 10 }).notNull(),
  dataCount: integer("data_count").default(1).notNull(),
  dataBatching: integer("data_batching").default(1).notNull(),
  alarm: json("alarm").default({
    prepare: false,
    filling: false,
    heating: false,
    sterilization: false,
    cooling: false,
    drain: false,
    end: false
  }).$type(),
  alarm_switch: boolean("alarm_switch").default(false).notNull(),
  prepare: json("prepareConfig").$type()
});
const schema = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  autoclave_config,
  role,
  sessions,
  users
}, Symbol.toStringTag, { value: "Module" }));
const client = postgres(DATABASE_URL);
const db = drizzle(client, { schema });

export { autoclave_config as a, db as d, sessions as s, users as u };
//# sourceMappingURL=index4-D0Nb1HJJ.js.map
