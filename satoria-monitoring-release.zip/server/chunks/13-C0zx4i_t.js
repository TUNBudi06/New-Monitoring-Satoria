const index = 13;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-D7XgzfLk.js')).default;
const imports = ["_app/immutable/nodes/13.CVLEvk0z.js","_app/immutable/chunks/BdY8nbO3.js","_app/immutable/chunks/N2H0PzE0.js","_app/immutable/chunks/DHUAlugP.js","_app/immutable/chunks/BtVlU6qO.js","_app/immutable/chunks/niT0dDKO.js","_app/immutable/chunks/Da_yRHvE.js","_app/immutable/chunks/Cn7nNa4a.js","_app/immutable/chunks/CFi_j4tm.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=13-C0zx4i_t.js.map
