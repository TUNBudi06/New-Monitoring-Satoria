const index = 15;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-DSZZ_eGT.js')).default;
const imports = ["_app/immutable/nodes/15.B51OwGaY.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/DXPuW9MO.js","_app/immutable/chunks/Bup8ca7u.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=15-DtpjYvYx.js.map
