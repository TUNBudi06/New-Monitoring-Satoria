import { d as db, u as users } from './index4-Bq3YGG3j.js';
import { eq } from 'drizzle-orm';
import 'drizzle-orm/postgres-js';
import 'postgres';
import 'drizzle-orm/pg-core';
import 'zod';
import './private-a70Od6j7.js';

const load = async (event) => {
  const jwt_cookie = event.cookies.get("refresh_token");
  let user;
  try {
    const payload = event.locals.jwt.decode(jwt_cookie);
    user = await db.select({
      username: users.username,
      email: users.email,
      firstname: users.firstname,
      lastname: users.lastname,
      type: users.role
    }).from(users).where(eq(users.id, payload.user_id)).limit(1).then((res) => res[0]);
  } catch (e) {
    console.error("JWT decode error:", e);
  }
  return {
    user: user || null
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CL04VooS.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.CID2jsHl.js","_app/immutable/chunks/DwO4VYHj.js","_app/immutable/chunks/D9-ZRGEK.js","_app/immutable/chunks/_e2Lk8Wl.js","_app/immutable/chunks/CvF72XlB.js","_app/immutable/chunks/Bb6RpWJL.js","_app/immutable/chunks/B5_kf4jH.js","_app/immutable/chunks/5Qpl9XkE.js","_app/immutable/chunks/BODWheSH.js","_app/immutable/chunks/YFp1XVmH.js","_app/immutable/chunks/DAul8e12.js","_app/immutable/chunks/BDwlTwo-.js","_app/immutable/chunks/B9LemL8W.js","_app/immutable/chunks/MIwj1XX2.js","_app/immutable/chunks/DPibCUq0.js","_app/immutable/chunks/W6geA9Qm.js","_app/immutable/chunks/DtYRfcXW.js","_app/immutable/chunks/ChGWCNSl.js","_app/immutable/chunks/B6SgTnaW.js","_app/immutable/chunks/KkXcApc5.js","_app/immutable/chunks/CgLEbebT.js","_app/immutable/chunks/CNDr1Z7s.js","_app/immutable/chunks/BdMBCV5W.js","_app/immutable/chunks/CKk6A1TW.js","_app/immutable/chunks/DtBtvVQy.js","_app/immutable/chunks/BGx13tzy.js","_app/immutable/chunks/jOYcctrt.js","_app/immutable/chunks/DkjyHJ0x.js","_app/immutable/chunks/X-gurY1T.js","_app/immutable/chunks/DROGpRSB.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-Bq1yrSox.js.map
