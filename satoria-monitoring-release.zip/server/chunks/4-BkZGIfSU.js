const index = 4;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BMvKVNpM.js')).default;
const imports = ["_app/immutable/nodes/4.CIV-fHBG.js","_app/immutable/chunks/SoUoNBie.js","_app/immutable/chunks/GEnObDzR.js","_app/immutable/chunks/83YYTNZR.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=4-BkZGIfSU.js.map
