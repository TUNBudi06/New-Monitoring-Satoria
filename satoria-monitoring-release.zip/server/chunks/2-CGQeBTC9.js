const load = async ({ locals }) => {
  return {
    user: "budi"
  };
};

var _layout_server_ts = /*#__PURE__*/Object.freeze({
  __proto__: null,
  load: load
});

const index = 2;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-CfhDPMKj.js')).default;
const server_id = "src/routes/(app)/+layout.server.ts";
const imports = ["_app/immutable/nodes/2.BBdUPXUG.js","_app/immutable/chunks/PQJWMyNa.js","_app/immutable/chunks/CaKK9ONF.js","_app/immutable/chunks/OKggTVyC.js","_app/immutable/chunks/BZF4576O.js","_app/immutable/chunks/B3ZxWL9O.js","_app/immutable/chunks/CSrnH8IZ.js","_app/immutable/chunks/BSnVJNDa.js","_app/immutable/chunks/4fFwGPg6.js","_app/immutable/chunks/CYlDMC1d.js","_app/immutable/chunks/CJfCnddR.js","_app/immutable/chunks/DjVnfXhZ.js","_app/immutable/chunks/BOk-cWR7.js","_app/immutable/chunks/biFvaynu.js","_app/immutable/chunks/_TQt2cNb.js","_app/immutable/chunks/BMWwaGIr.js","_app/immutable/chunks/DKLSPblt.js","_app/immutable/chunks/Lju-gjNC.js","_app/immutable/chunks/CJnGcTFu.js","_app/immutable/chunks/Ba1Xx48m.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, _layout_server_ts as server, server_id, stylesheets };
//# sourceMappingURL=2-CGQeBTC9.js.map
