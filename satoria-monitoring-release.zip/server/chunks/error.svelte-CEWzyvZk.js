import { p as push, f as escape_html, e as pop } from './index2-vHIvx7nE.js';
import { p as page } from './index3-CwpwUk7g.js';
import './exports-Cca4-Om4.js';

function Error($$payload, $$props) {
  push();
  $$payload.out += `<h1>${escape_html(page.status)}</h1> <p>${escape_html(page.error?.message)}</p>`;
  pop();
}

export { Error as default };
//# sourceMappingURL=error.svelte-CEWzyvZk.js.map
