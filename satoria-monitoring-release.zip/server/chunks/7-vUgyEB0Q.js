const index = 7;
let component_cache;
const component = async () => component_cache ??= (await import('./_page.svelte-BMvKVNpM.js')).default;
const imports = ["_app/immutable/nodes/7.CXaUo1si.js","_app/immutable/chunks/BFOTuOyR.js","_app/immutable/chunks/CBtRJagN.js","_app/immutable/chunks/DuSXapKN.js"];
const stylesheets = [];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=7-vUgyEB0Q.js.map
