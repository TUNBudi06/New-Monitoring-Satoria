class MediaQuery {
  current;
  /**
   * @param {string} query
   * @param {boolean} [matches]
   */
  constructor(query, matches = false) {
    this.current = matches;
  }
}
function createSubscriber(_) {
  return () => {
  };
}

export { MediaQuery as M, createSubscriber as c };
//# sourceMappingURL=index-server-DH7p7JOq.js.map
