const index = 0;
let component_cache;
const component = async () => component_cache ??= (await import('./_layout.svelte-0yB81X2U.js')).default;
const imports = ["_app/immutable/nodes/0.D_bCEyoE.js","_app/immutable/chunks/B61r4iaH.js","_app/immutable/chunks/CLxiUi4l.js","_app/immutable/chunks/ByuCpQji.js"];
const stylesheets = ["_app/immutable/assets/0.DiRgl5yq.css"];
const fonts = [];

export { component, fonts, imports, index, stylesheets };
//# sourceMappingURL=0-B9NdCsRN.js.map
