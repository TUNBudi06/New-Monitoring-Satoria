const load = async ({ locals }) => {
  return {
    user: "budi"
  };
};
export {
  load
};
